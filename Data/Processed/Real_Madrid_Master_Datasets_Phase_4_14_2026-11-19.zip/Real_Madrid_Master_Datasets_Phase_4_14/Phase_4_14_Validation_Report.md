# Phase 4.14 — Master Dataset Integration & Final Data Quality Audit

**Release date:** 19 November 2026  
**Release package:** `Real_Madrid_Master_Datasets_Phase_4_14_2026-11-19.zip`  
**Status:** Integrated and audited; known limitations remain documented.

## 1. Executive summary

The approved Phase 4.13 match and player-competition derivatives have been integrated into a new versioned master package. The Phase 4.12 source tables were preserved as immutable snapshots, and all other canonical data tables were carried forward unchanged.

- Canonical match master: **630 rows / 630 unique match IDs**.
- Match-team statistics: **630 rows**, with exact one-to-one match-ID coverage against the match master.
- Harmonized player-competition statistics: **343 rows**, including restored `season_role` from the source snapshot.
- Copa del Rey goals: **110 player-attributed + 6 opponent own goals = 116 team match goals**.
- Player-season statistics: **386 rows**.
- Transfer transactions: **214 rows** (82 incoming; 132 outgoing).
- Financial facts: **204 rows**.
- Trophy records: **22 derived records**.
- Source register: **20 entries**.
- Field-level data dictionary: **261 field definitions**.
- Cross-dataset validation: **26 PASS; 1 DOCUMENTED; 0 FAIL**.

## 2. Integration decisions

### Canonical tables updated
1. `Real_Madrid_All_Matches.csv` now uses the Phase 4.13 clean derivative. It retains the original opponent label in `opponent_raw_phase_4_12`, adds scoped dataset-level source references, and preserves all 630 match IDs.
2. `Real_Madrid_Player_Competition_Stats.csv` now uses the 343-row harmonized Phase 4.13 schema. The `season_role` field was restored from the Phase 4.12 source rows by season, preserving the historical baseline distinction.

### Original source state preserved
- The original 630-row Phase 4.12 match master is stored under `Source_Snapshots/Phase_4_12/`.
- The original 345-row source-specific player-competition table is stored under `Source_Snapshots/Phase_4_12/`.
- The original Phase 4.12 inventory, quality log and source register are also retained as snapshots.
- Other canonical data tables were copied byte-for-byte from the Phase 4.12 master package.

### Supporting audit material
The full Phase 4.13 remediation evidence is retained under `Audit_Archive/Phase_4_13/`, including the own-goal event register, goal reconciliation, UCL name crosswalk, excluded header artifacts, source references, finding log and validation report.

## 3. Final dataset inventory

| Dataset | Records | Current status |
|---|---:|---|
| Real_Madrid_All_Matches.csv | 630 | Phase 4.13 clean derivative; 630 records; 629 played + 1 cancelled |
| Real_Madrid_Match_Team_Stats.csv | 630 | Populated; 630 rows; 616 Sports Reference match logs + 14 CWC result-only rows |
| Real_Madrid_Player_Season_Stats.csv | 386 | Populated; corrected 2022-23 replacement; provisional IDs |
| Real_Madrid_Player_Competition_Stats.csv | 343 | Phase 4.13 harmonized; 343 analytical rows |
| Real_Madrid_Player_Match_Stats.csv | 0 | Schema only — intentionally unpopulated |
| Real_Madrid_Transfers.csv | 214 | Populated; 0 arrivals and 0 departures |
| Real_Madrid_Player_ID_Crosswalk.csv | 158 | Populated; provisional name-derived IDs |
| Real_Madrid_Financials.csv | 204 | Populated; 204 metric rows |
| Real_Madrid_Trophies.csv | 22 | Populated; derived records |
| Real_Madrid_La_Liga_Standings.csv | 11 | Populated; 11 rows |
| Source_Register.csv | 20 | Updated; 20 source entries |
| Data_Quality_Log.csv | 41 | Updated; 41 findings |
| Data_Dictionary.csv | 0 | Field-level dictionary generated in Phase 4.14 |

The 2015-16 season remains a historical baseline and must not be silently combined with main-period totals.

## 4. Cross-dataset validation

| check                                                   | observed                                                     | expected                 | status     | notes                                                                                                                               |
|:--------------------------------------------------------|:-------------------------------------------------------------|:-------------------------|:-----------|:------------------------------------------------------------------------------------------------------------------------------------|
| Canonical match rows                                    | 630                                                          | 630                      | PASS       | Phase 4.13 clean match master integrated.                                                                                           |
| Unique match IDs                                        | 630                                                          | 630                      | PASS       | No duplicate match identifiers.                                                                                                     |
| Match-team stats rows                                   | 630                                                          | 630                      | PASS       | Preserved unchanged from Phase 4.12 master.                                                                                         |
| Match ID set equality: match master vs match-team stats | 630                                                          | 630                      | PASS       | Only in match master: 0; only in match-team stats: 0.                                                                               |
| Played vs cancelled event counts                        | 629 played / 1 cancelled                                     | 629 played / 1 cancelled | PASS       | Cancelled Cádiz return fixture remains excluded from played-match KPIs.                                                             |
| UCL opponent country-code prefix check                  | 0                                                            | 0                        | PASS       | Legitimate club prefixes such as RB are not treated as country codes.                                                               |
| Spanish Super Cup 2017 verified venues                  | 2                                                            | 2                        | PASS       | Camp Nou and Santiago Bernabéu; official retrospective reference retained.                                                          |
| Copa del Rey season goal reconciliation                 | 11                                                           | 11                       | PASS       | 110 player goals + 6 opponent own goals = 116 team goals.                                                                           |
| Own-goal event match verification                       | 6                                                            | 6                        | PASS       | Each event links to a played Copa del Rey match with matching Real Madrid score.                                                    |
| Harmonized player-competition rows                      | 343                                                          | 343                      | PASS       | 290 Copa del Rey + 53 FIFA Club World Cup player-competition rows.                                                                  |
| Unique player-competition keys                          | 343                                                          | 343                      | PASS       | Composite key includes player candidate, season, competition and edition.                                                           |
| Missing competition edition values                      | 0                                                            | 0                        | PASS       | 29 Copa del Rey 2025-26 rows assigned edition 2025.                                                                                 |
| Competition-stat season_role values restored            | 343                                                          | 343                      | PASS       | Mapped from the immutable Phase 4.12 source rows by season; baseline remains labelled Baseline.                                     |
| Repeated header artifacts preserved in audit            | 2                                                            | 2                        | PASS       | Excluded from canonical analytical table; evidence retained in Phase 4.13 audit archive.                                            |
| Player-season row count                                 | 386                                                          | 386                      | PASS       | Season-level all-competitions aggregates preserved.                                                                                 |
| Player-season composite key duplicates                  | 0                                                            | 0                        | PASS       | Provisional player key + season; player identifiers remain name-derived.                                                            |
| Player ID crosswalk key duplicates                      | 0                                                            | 0                        | PASS       | Crosswalk remains provisional, not an authoritative external ID registry.                                                           |
| Season-stat player keys missing from crosswalk          | 0                                                            | 0                        | PASS       | All player season candidates map to the current crosswalk.                                                                          |
| Transfer player keys missing from crosswalk             | 0                                                            | 0                        | PASS       | All transfer player candidates map to the current crosswalk.                                                                        |
| Transfer transaction rows / unique IDs                  | 214 / 214                                                    | 214 / 214                | PASS       | 82 incoming; 132 outgoing; 91 rows have neither a numeric transfer fee nor a numeric loan fee; 20 additional rows have a loan fee while transfer_fee is blank.                                                                         |
| Financial fact natural-key duplicates                   | 0                                                            | 0                        | PASS       | Natural key includes reporting period, metric, segment, data type and reporting entity scope.                                       |
| Trophy records / unique IDs                             | 22 / 22                                                      | 22 / 22                  | PASS       | Trophy records remain derived and still require official honours cross-check before final publication.                              |
| La Liga standings rows / unique seasons                 | 11 / 11                                                      | 11 / 11                  | PASS       | Calculated standings; official final-table cross-check remains recommended.                                                         |
| Player-match statistics records                         | 0                                                            | 0                        | DOCUMENTED | Header-only schema is intentional; no player-by-match source records were supplied.                                                 |
| Source register rows / unique source IDs                | 20 / 20                                                      | 20 / 20                  | PASS       | Adds five event-level source references; unknown original URLs/licensing remain blank.                                              |
| Source snapshot integrity                               | Original Phase 4.12 match and competition CSV bytes retained | Exact source bytes       | PASS       | Immutable source snapshots are stored separately under Source_Snapshots/Phase_4_12.                                                 |
| Unchanged canonical dataset tables                      | 8 tables byte-for-byte preserved                             | 8 tables                 | PASS       | Match-team stats, season stats, player crosswalk, player-match schema, transfers, financials, trophies and standings are unchanged. |

## 5. Important data controls

- Match/event grain is one row per `match_id`; cancelled events remain in the register but are not played matches.
- Match-team statistics are team-level, not individual player-match performance.
- Player-competition statistics are competition aggregates, not player-match rows.
- Player identifiers are provisional name-derived keys.
- Transfer rows represent transactions; loan returns and permanent transfers can be separate valid events.
- Missing fees are not zero; **91 of 214** rows have neither a numeric transfer fee nor a numeric loan fee. A further 20 rows have a loan fee while the permanent transfer-fee field is blank.
- Financial rows retain original units, normalized EUR million values where available, data type and entity scope.
- Standalone financial reporting through 2020-21 and consolidated reporting from 2021-22 are not directly comparable without qualification.
- 2025-26 actual financial information is a results announcement summary, not full audited annual accounts.
- Trophy records and La Liga standings remain derived and still require official reference cross-checks before final publication.
- Player-match statistics remain schema-only because no individual player-by-match source records were supplied.
- Historical FIFA Club World Cup player aggregates for 2016, 2017 and 2018 remain unavailable.
- La Liga and UEFA Champions League competition-specific player aggregates are not present.

## 6. Source provenance

The source register now contains 20 source entries. Dataset/repository landing URLs, official validation URLs and event-level evidence URLs are separately scoped. The exact original download URL, retrieval version, access date or reuse licence is still unavailable for several user-supplied exports; those gaps are explicitly retained rather than guessed.

## 7. PostgreSQL readiness

The package includes `PostgreSQL_Load_Readiness.md` and `Data_Model_Grain_Map.csv`. These are design aids, not a claim that a PostgreSQL database has already been created or loaded.

Before loading:
1. Create dimension and fact tables according to the documented grain.
2. Treat the provisional player key as a staging key until identity validation is completed.
3. Keep `season` distinct from `competition_edition`.
4. Preserve `entity_scope`, `data_type`, `original_unit` and source references in financial facts.
5. Load empty player-match schema as a documented unavailable dataset, not as a populated fact table.
6. Use staging tables and run row-count/key checks before promoting to production tables.

## 8. Release decision

**Master integration: PASS.**  
**Cross-dataset integrity: PASS with documented limitations.**  
**Publication readiness: NOT FINAL.** Remaining official honours, league-table and source/licensing checks must be completed before public release.

Use this Phase 4.14 package as the current master-data handoff. Keep the Phase 4.12 package and uploaded raw archives unchanged.
