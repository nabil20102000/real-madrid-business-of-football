# Master Dataset Changelog — Phase 4.14

**Date:** 19 November 2026

## Canonical dataset updates
1. Replaced `Real_Madrid_All_Matches.csv` with the Phase 4.13 clean 630-row derivative; all match IDs preserved.
2. Replaced `Real_Madrid_Player_Competition_Stats.csv` with the harmonized 343-row analytical table.
3. Restored `season_role` in the harmonized player-competition table from the Phase 4.12 source rows.
4. Updated `Source_Register.csv` to 20 source entries, including five event-level Copa del Rey own-goal references.
5. Updated `Data_Quality_Log.csv` with Phase 4.13 remediation and Phase 4.14 integration findings.
6. Updated `Dataset_Inventory.csv` and created field-level `Data_Dictionary.csv`.

## Preservation controls
- Phase 4.12 `Real_Madrid_All_Matches.csv` preserved byte-for-byte under `Source_Snapshots/Phase_4_12/`.
- Phase 4.12 `Real_Madrid_Player_Competition_Stats.csv` preserved byte-for-byte under `Source_Snapshots/Phase_4_12/`.
- Phase 4.12 inventory, quality log and source register preserved under `Source_Snapshots/Phase_4_12/`.
- The Phase 4.13 remediation package is archived under `Audit_Archive/Phase_4_13/`.
- The following eight canonical datasets were carried forward byte-for-byte: match-team stats, player-season stats, player ID crosswalk, player-match schema, transfers, financials, trophies and La Liga standings.
- Original user-uploaded raw archives and PDFs were not modified.

## Validation
- Match master: 630 rows / 630 unique match IDs.
- Match-team statistics: 630 rows and exact match-ID set equality with the match master.
- Player-competition stats: 343 rows / 343 unique composite keys.
- Copa del Rey goals: 110 player-attributed + 6 opponent own goals = 116 team match goals.
- Cross-dataset checks and known limitations are documented in `Phase_4_14_Validation_Report.md`.
