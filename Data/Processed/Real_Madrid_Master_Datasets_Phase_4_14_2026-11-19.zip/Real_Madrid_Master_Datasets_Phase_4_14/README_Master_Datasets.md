# Real Madrid — Master Datasets (Phase 4.14)

**Release date:** 19 November 2026  
**Project:** Real Madrid: The Business of Football — A Decade of Sporting Performance, Financial Growth and Strategic Investment

This is the current versioned master-data handoff. It integrates the approved Phase 4.13 clean match and harmonized player-competition derivatives. It is not yet a public-release or final-analytics dataset.

## Scope
- Historical baseline: 2015-16 (`season_role=Baseline`)
- Main analytical period: 2016-17 through 2025-26
- Men's senior first team; Real Madrid-centric records.

## Canonical datasets

| File | Rows | Grain / purpose |
|---|---:|---|
| `Real_Madrid_All_Matches.csv` | 630 | Real Madrid match/event register; competition landing URLs are explicitly dataset-level; neutral UCL assignments and unavailable regulation scores remain blank. |
| `Real_Madrid_Match_Team_Stats.csv` | 630 | Team-level match context, not player-level match stats; 14 CWC rows have no matching Sports Reference team log. |
| `Real_Madrid_Player_Season_Stats.csv` | 386 | All-competition season aggregates; not complete separate La Liga/UCL competition splits. |
| `Real_Madrid_Player_Competition_Stats.csv` | 343 | Competition aggregates only; 56 zero-appearance rows retained; no complete La Liga/UCL competition splits; original 345-row source table retained in Source_Snapshots. |
| `Real_Madrid_Player_Match_Stats.csv` | 0 | No individual player-by-match performance records supplied; do not infer from team match logs. |
| `Real_Madrid_Transfers.csv` | 214 | Transfermarkt overview; exact dates absent; 91 of 214 rows have neither a numeric transfer fee nor a numeric loan fee; 20 additional rows have a loan fee while transfer_fee is blank; loan fees and permanent fees remain separate. |
| `Real_Madrid_Player_ID_Crosswalk.csv` | 158 | IDs are not official source identifiers; aliases/collisions should be reviewed before production joins. |
| `Real_Madrid_Financials.csv` | 204 | Reporting scope changes from standalone through 2020-21 to consolidated from 2021-22; 2025-26 actuals are announcement summary, not audited accounts. |
| `Real_Madrid_Trophies.csv` | 22 | 22 trophy records derived from results/standings; official honours cross-check remains open. |
| `Real_Madrid_La_Liga_Standings.csv` | 11 | Calculated from 380-match season files; official final-table cross-check remains recommended. |

## Phase 4.13 corrections integrated
- All 133 UEFA Champions League opponent display labels normalized; raw values retained in `opponent_raw_phase_4_12`.
- Copa del Rey team goals reconcile: 110 player-attributed goals + 6 opponent own goals = 116 team goals.
- Two repeated player-competition header artifacts excluded from the harmonized table and preserved in the audit archive.
- 29 Copa del Rey 2025-26 rows assigned `competition_edition=2025`.
- Competition-level player statistics harmonized to 343 rows.
- 2017 Spanish Super Cup venues populated from a Real Madrid official retrospective.

## Version lineage and source preservation
- Phase 4.12 master tables that were replaced are preserved under `Source_Snapshots/Phase_4_12/`.
- The Phase 4.12 inventory, data-quality log and source register are also preserved as snapshots.
- The Phase 4.13 remediation evidence is preserved under `Audit_Archive/Phase_4_13/`.
- Other canonical data tables were copied byte-for-byte from the Phase 4.12 master ZIP.
- Uploaded raw ZIPs and PDFs were not modified.

## Critical analytical limitations
1. `Real_Madrid_Player_Match_Stats.csv` is header-only; no individual player-by-match performance data was supplied.
2. Player IDs are provisional name-derived identifiers, not official IDs.
3. Competition player aggregates cover Copa del Rey and FIFA Club World Cup 2022/2025 only; complete La Liga/UCL splits are unavailable.
4. FIFA Club World Cup player aggregates for editions 2016/2017/2018 are unavailable.
5. Transfer data has 82 incoming and 132 outgoing transactions; exact dates are not supplied for all transactions and 91 of 214 rows have neither a numeric transfer fee nor a numeric loan fee. Missing fees are not zero.
6. Financial reporting scope changes from standalone club reporting through 2020-21 to consolidated group reporting from 2021-22.
7. 2025-26 actual financial facts are based on an official results summary, not full audited annual accounts.
8. Trophy records and La Liga standings are derived and still require official honours/table cross-checks.
9. Some exact source URLs, retrieval versions and reuse/licence details remain unavailable.

## PostgreSQL preparation
See `PostgreSQL_Load_Readiness.md` and `Data_Model_Grain_Map.csv`. These documents define proposed grains and loading controls; they do not claim a database has been created or populated.

## Package contents
- Canonical CSV datasets.
- `Dataset_Inventory.csv`, `Data_Quality_Log.csv`, `Source_Register.csv`, `Data_Dictionary.csv`.
- `Phase_4_14_Validation_Report.md` and `Phase_4_14_Validation_Checks.csv`.
- `Data_Model_Grain_Map.csv` and `PostgreSQL_Load_Readiness.md`.
- `Source_Snapshots/Phase_4_12/` and `Audit_Archive/Phase_4_13/`.
