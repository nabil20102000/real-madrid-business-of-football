# PostgreSQL Load Readiness — Phase 4.14

## Status
The Phase 4.14 CSV package is consolidated and cross-checked. PostgreSQL has **not** yet been created or loaded.

## Recommended fact-table grain and keys

| Proposed table | Source | Grain | Candidate key |
|---|---|---|---|
| FactMatches | Real_Madrid_All_Matches.csv | One row per Real Madrid match/event | match_id |
| FactMatchTeamStats | Real_Madrid_Match_Team_Stats.csv | One row per match_id | match_id |
| FactPlayerSeasonStats | Real_Madrid_Player_Season_Stats.csv | One row per player candidate per football season | player_key_candidate + season |
| FactPlayerCompetitionStats | Real_Madrid_Player_Competition_Stats.csv | One row per player candidate, season, competition and edition | player_competition_key |
| FactTransfers | Real_Madrid_Transfers.csv | One row per transfer transaction | transfer_id |
| FactFinancials | Real_Madrid_Financials.csv | One row per reporting period, metric, segment, data type and entity scope | Composite natural key |
| FactTrophies | Real_Madrid_Trophies.csv | One row per trophy/title record | trophy_id |
| FactLaLigaStandings | Real_Madrid_La_Liga_Standings.csv | One row per Real Madrid season final table | season |
| DimPlayer | Real_Madrid_Player_ID_Crosswalk.csv | One row per provisional player identity candidate | player_key_candidate |
| DimSeason | Derived from season fields in fact tables | One row per football season | season |
| DimCompetition | Derived from competition fields in fact tables | One row per competition name | competition |

## Loading order
1. Create staging schema and import source CSVs into staging tables.
2. Validate encoding, data types, null handling and row counts.
3. Load dimensions (season, competition, player, financial category/date as appropriate).
4. Load fact tables after dimension key checks.
5. Add primary/foreign keys only after the candidate-key checks pass.
6. Create analytical views after reconciliation.

## Mandatory controls
- Keep 2015-16 `Baseline` distinct from the 2016-17 to 2025-26 main period.
- Do not equate `season` with `competition_edition`.
- Preserve `match_status`; the cancelled event is not a played match.
- Keep penalty shootout values separate from match goals.
- Do not turn missing numeric transfer fees or player metrics into zero.
- Preserve financial `entity_scope`, `data_type`, `original_unit`, `currency` and source page.
- Do not treat the player-match schema-only CSV as a populated fact table.
- Do not use name-derived player IDs as permanent external identifiers.
- Keep the 14 CWC rows without detailed team match logs; their missing match-log fields are intentional.
- Preserve `player_competition_key` only as a current staging key; review name aliases before production constraints.

## Suggested SQL data types
- IDs and labels: `TEXT` (unless a stable numeric surrogate is introduced).
- Dates: `DATE`.
- Counts and scores: `INTEGER`.
- Minutes, rates, percentages, financial values: `NUMERIC` with suitable precision.
- Flags: `BOOLEAN`.
- Source metadata and notes: `TEXT`.

## Release gates before production loading
- Official honours cross-check for 22 trophy records.
- Official La Liga final-table cross-check for 11 seasons.
- Player identity/alias review.
- Confirm source URLs, source versions and licensing/reuse terms where possible.
- Confirm whether missing La Liga/UCL player-competition splits are required for planned analysis.
