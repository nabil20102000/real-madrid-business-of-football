# Real Madrid — Phase 4.16 PostgreSQL Architecture & Controlled Loading

**Release date:** 19 November 2026  
**Base data release:** Phase 4.15  
**Target:** PostgreSQL 13+  
**Status:** Deployment package generated; no live PostgreSQL server was connected from this environment.

## What Phase 4.16 delivers

- Three-schema architecture: `raw`, `core`, `audit`.
- Raw staging tables for all **21 top-level Phase 4.15 CSV files**, using TEXT columns to preserve source values before casting.
- Curated, typed core tables for match, team-match, player-season, player-competition, player-match (empty source schema), transfers, financials, trophies and La Liga standings.
- Conformed dimensions for season, competition, competition edition and provisional player identity.
- Primary keys, foreign keys, uniqueness constraints and query indexes.
- Audit/provenance tables for source register, data quality, inventory, data dictionary, identity audit, official validation and prior phase QA checks.
- Controlled raw-to-core loading and SQL assertions against Phase 4.15 expected counts.
- Initial read-only analytical views.

## Database model

### `raw` — immutable landing layer
Every supplied CSV is loaded into a matching `raw.*` table. Every field is TEXT at this stage. This preserves source text and separates import errors from curated data types.

### `core` — typed analytical model
- `dim_season`, `dim_competition`, `dim_competition_edition`, `dim_player`
- `fact_matches`, `fact_match_team_stats`
- `fact_player_season_stats`, `fact_player_competition_stats`, `fact_player_match_stats`
- `fact_transfers`, `fact_financials`, `fact_trophies`, `fact_laliga_standings`
- `player_name_alias_crosswalk`

Player keys remain explicitly provisional. The `fact_player_match_stats` table is intentionally empty because Phase 4.15 supplied a schema only; it is not populated with invented records. Its optional internal `player_key_candidate` foreign key is left NULL until a player-match source row is available and mapped. The supplied `player_id` field is retained as source text and is not treated as an authoritative join key.

### `audit` — provenance and validation
Source register, data quality log, inventory, dictionary, grain map, player identity audit, official trophy and standings validation, Phase 4.14/4.15 QA checks and database load runs.

## Load instructions

Run commands from the directory that contains `Real_Madrid_Phase_4_16/` after extracting this package.

1. Create the database as an administrator:

```bash
psql -d postgres -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/00_create_database.sql
```

2. Create namespaces and raw tables:

```bash
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/01_create_schemas.sql
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/02_create_raw_staging.sql
```

3. Load the CSV files into raw staging (this is a `psql` script because it uses client-side `\copy`):

```bash
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/03_load_raw_csvs.psql
```

4. Create curated tables and load them:

```bash
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/04_create_core_tables.sql
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/05_load_core.sql
```

5. Run assertions and create views:

```bash
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/06_validate.sql
psql -d real_madrid_analytics -v ON_ERROR_STOP=1 -f Real_Madrid_Phase_4_16/sql/07_create_views.sql
```

6. Review counts and load history:

```sql
SELECT * FROM audit.load_run ORDER BY load_run_id DESC;
SELECT table_schema, table_name FROM information_schema.tables
WHERE table_schema IN ('raw','core','audit') ORDER BY table_schema, table_name;
```

## Expected row counts

| Table | Expected rows |
|---|---:|
| `core.fact_matches` | 631 |
| `core.fact_match_team_stats` | 631 |
| `core.fact_player_season_stats` | 386 |
| `core.fact_player_competition_stats` | 343 |
| `core.fact_player_match_stats` | 0 |
| `core.fact_transfers` | 214 |
| `core.fact_financials` | 204 |
| `core.fact_trophies` | 23 |
| `core.fact_laliga_standings` | 11 |
| `core.dim_player` | 157 |
| `core.player_name_alias_crosswalk` | 159 |

## Critical modeling controls

1. Keep football `season` distinct from competition `competition_edition`.
2. Preserve FIFA Club World Cup Morocco 2022 as edition 2022, even though its final was played in 2023.
3. Keep FIFA Intercontinental Cup 2024 as a separate competition.
4. Do not treat the 15 result-only team-match rows as detailed team performance logs.
5. Do not treat `RMPLR-*` player IDs as official external IDs.
6. Keep missing transfer fees and performance fields NULL, not zero.
7. Preserve financial entity scope, original unit and comparability notes.
8. Keep source evidence URLs and their declared scope.
9. Do not load Phase 4.14 snapshot copies as current fact tables; they are historical lineage only.

## Validation and limitations

`sql/06_validate.sql` raises an exception if the expected Phase 4.15 row counts or key relationships fail. `tests/preflight_validate.py` performs a 35-item offline CSV/type/key/dimension preflight (34 PASS; 1 live-deployment check NOT RUN) without needing a PostgreSQL server. The report is in `Phase_4_16_Validation_Checks.csv`.

**Not yet completed:** a live PostgreSQL deployment. This environment has no PostgreSQL server/client binary and no connection credentials/endpoint. The generated SQL is a deployment artifact, not proof of a live database load. PostgreSQL execution, permissions, backup policy and server-specific query-plan review remain to be performed on the target instance.
