# Phase 4.16 — PostgreSQL Architecture & Controlled Data Loading

**Release date:** 19 November 2026  
**Base release:** Phase 4.15  
**Target:** PostgreSQL 13+  
**Status:** Deployment package prepared and offline-validated; live PostgreSQL deployment pending target-server access.

## 1. Executive summary

Phase 4.16 is the final planned stage of Phase 4 in the roadmap established by the Phase 4.15 handoff. It packages the Phase 4.15 data as a PostgreSQL-ready relational model with staging, curated, audit and validation layers.

- **21** Phase 4.15 CSV files included as raw import sources.
- **3** schemas: `raw`, `core`, `audit`.
- **21** raw staging tables, each retaining source fields as TEXT before casting.
- **14** curated core tables: 4 dimensions, 9 fact tables and 1 player-alias bridge.
- **11** audit tables including load-run history.
- **9** SQL/psql scripts for database setup, DDL, CSV import, controlled loading, validation, views and optional reset.
- **35 offline checks: PASS**, with zero failures.
- **Live PostgreSQL execution: NOT RUN**. This environment has no PostgreSQL server/client binary or target connection credentials/endpoint. No live database creation or loading is claimed.

## 2. Architecture

### `raw` — source landing layer
One raw table for each of the 21 top-level Phase 4.15 CSV files. All columns are TEXT so the incoming CSV payload is preserved before type conversion. The raw layer can be reloaded independently and is not overwritten by the curated load.

### `core` — typed relational model

**Dimensions**
- `dim_season` — one row per football season; baseline role retained.
- `dim_competition` — one row per competition name.
- `dim_competition_edition` — separate competition edition key; season is not used as a substitute.
- `dim_player` — 157 provisional player candidates; all explicitly marked provisional.

**Facts and bridge**
- `fact_matches` — one row per match/event; 631 rows.
- `fact_match_team_stats` — one row per match; 631 rows, with a one-to-one FK to the match master.
- `fact_player_season_stats` — one row per player candidate per season; 386 rows.
- `fact_player_competition_stats` — one row per player candidate, season, competition and edition; 343 rows.
- `fact_player_match_stats` — schema only; 0 rows. No player-match records are invented.
- `fact_transfers` — one row per transaction; 214 rows.
- `fact_financials` — 204 rows; generated surrogate key preserves rows where candidate natural keys contain NULL segment values.
- `fact_trophies` — 23 title records.
- `fact_laliga_standings` — 11 season rows.
- `player_name_alias_crosswalk` — 159 source spelling aliases for the 157 provisional player candidates.

### `audit` — lineage and QA
Official trophy and standings validation, player identity audit, source register, data quality log, dataset inventory, data dictionary, data model grain map, Phase 4.14 and 4.15 QA checks, and load-run history.

The source data quality log contains repeated `finding_id` values. A generated `data_quality_row_id` is used instead of imposing a false uniqueness constraint; all 47 source rows are retained.

## 3. Key relational and data controls

1. `season` and `competition_edition` are separate attributes and dimensions.
2. FIFA Club World Cup Morocco 2022 remains edition 2022 even though its final date is in 2023.
3. FIFA Intercontinental Cup 2024 remains a distinct competition.
4. `fact_match_team_stats.match_id` is both a primary key and foreign key to `fact_matches.match_id`.
5. Fifteen team-match rows are result-only; `match_log_available=false` is retained and these rows must not be interpreted as detailed performance logs.
6. Player-season key: `(player_key_candidate, season)`.
7. Player-competition key: `player_competition_key`.
8. Transfer key: `transfer_id`; loan return and permanent transfer records remain separate.
9. Financial and data-quality rows use surrogate identities where source natural keys are nullable or repeated.
10. `RMPLR-*` identifiers remain provisional. The raw `player_id` field in the empty player-match table is not linked to the provisional player dimension; an optional `player_key_candidate` FK is available for future resolved joins.
11. Missing fees and performance values remain NULL, not zero.
12. Financial reporting scope, original unit, EUR million normalization and source references are retained.

## 4. Source row-count baseline

| Core table | Expected rows |
|---|---:|
| `fact_matches` | 631 |
| `fact_match_team_stats` | 631 |
| `fact_player_season_stats` | 386 |
| `fact_player_competition_stats` | 343 |
| `fact_player_match_stats` | 0 |
| `fact_transfers` | 214 |
| `fact_financials` | 204 |
| `fact_trophies` | 23 |
| `fact_laliga_standings` | 11 |
| `dim_player` | 157 |
| `player_name_alias_crosswalk` | 159 |

The database post-load SQL asserts these counts and selected FK relationships.

## 5. Deployment order

1. `sql/00_create_database.sql` — create the database as an administrator.
2. `sql/01_create_schemas.sql` — create schemas and load-run table.
3. `sql/02_create_raw_staging.sql` — create raw tables.
4. `sql/03_load_raw_csvs.psql` — truncate raw landing tables and import all packaged CSVs with psql client-side `\copy`.
5. `sql/04_create_core_tables.sql` — create dimensions, typed facts, bridge and audit tables.
6. `sql/05_load_core.sql` — truncate curated targets and load dimensions, facts and audit rows in dependency order.
7. `sql/06_validate.sql` — assert expected counts and relationships; raises an exception on failure.
8. `sql/07_create_views.sql` — create initial read-only views.

Exact commands and working-directory assumptions are in `README_Phase_4_16.md`.

## 6. Offline validation results

**34 offline checks PASS; 0 failures. One live PostgreSQL deployment check is marked NOT RUN.** The preflight verifies:
- All 21 CSV row counts against Phase 4.15.
- Type compatibility for mapped BIGINT, NUMERIC, DATE and BOOLEAN values.
- Declared source-key uniqueness (with surrogate-key exceptions documented).
- Exact match/team-match `match_id` set equality.
- Player-key coverage from season, competition and transfer tables to the crosswalk.
- Dimension coverage: 11 seasons, 7 competitions and 39 competition-edition pairs.
- 630 played and 1 cancelled match records.
- 15 result-only team-match rows.
- The 18 December 2024 Pachuca 0-3 Real Madrid Intercontinental Cup final.
- Presence of all 9 deployment SQL/psql scripts.

See `Phase_4_16_Validation_Checks.csv` and `tests/preflight_result.json`.

## 7. Live PostgreSQL status and limitations

A PostgreSQL server/client was not available in this environment and no target server connection was supplied. Therefore:
- The database has **not** been created on a live PostgreSQL instance.
- The `\copy` import and PostgreSQL DDL have **not** been executed against a server.
- Foreign-key and row-count assertions in `sql/06_validate.sql` are deployment-time tests, not yet server-confirmed.
- Server permissions, backup/restore, query plans, connection security and performance still require target-instance review.

The ZIP contains deployment-ready scripts and data, not a running PostgreSQL database or database dump.

## 8. Phase 4 closure decision

**Phase 4.16 is the final planned stage of Phase 4.** The data model, DDL, staging import, load transformations, validation SQL and documentation are prepared. Phase 4 can be considered *package-complete* now; it should be marked *database-deployed* only after the target PostgreSQL server executes the scripts successfully and `06_validate.sql` passes there.

Open limitations carried forward from Phase 4.15 remain unchanged: provisional player IDs, incomplete player-match data, some historical official-table coverage, and source licensing/reuse checks.
