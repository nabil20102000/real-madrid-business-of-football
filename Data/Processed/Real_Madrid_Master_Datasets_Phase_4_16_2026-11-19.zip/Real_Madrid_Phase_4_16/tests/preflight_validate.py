#!/usr/bin/env python3
"""Offline Phase 4.16 preflight; standard library only, no PostgreSQL connection."""
from pathlib import Path
from decimal import Decimal
from datetime import date
import csv,json,sys
BASE=Path(__file__).resolve().parents[1]; DATA=BASE/'data'
EXPECTED={'Real_Madrid_All_Matches.csv':631,'Real_Madrid_Match_Team_Stats.csv':631,'Real_Madrid_Player_Season_Stats.csv':386,'Real_Madrid_Player_Competition_Stats.csv':343,'Real_Madrid_Player_Match_Stats.csv':0,'Real_Madrid_Transfers.csv':214,'Real_Madrid_Financials.csv':204,'Real_Madrid_Trophies.csv':23,'Real_Madrid_La_Liga_Standings.csv':11,'Real_Madrid_Player_ID_Crosswalk.csv':157,'Player_Name_Alias_Crosswalk.csv':159,'Player_Identity_Audit.csv':157,'Trophy_Official_Validation.csv':23,'LaLiga_Standings_Official_Validation.csv':11,'Source_Register.csv':41,'Data_Quality_Log.csv':47,'Data_Dictionary.csv':313,'Dataset_Inventory.csv':32,'Data_Model_Grain_Map.csv':11,'Phase_4_14_Validation_Checks.csv':27,'Phase_4_15_Validation_Checks.csv':27}
checks=[]; failures=[]; rows_by_file={}; headers={}
def add(name,obs,exp,status,note=''):
 checks.append({'check':name,'observed':str(obs),'expected':str(exp),'status':status,'notes':note})
def read(name):
 with (DATA/name).open(encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f); return r.fieldnames,list(r)
for fn,expected in EXPECTED.items():
 try:
  cols,rows=read(fn); rows_by_file[fn]=rows; headers[fn]=set(cols)
  ok=len(rows)==expected; add('row_count:'+fn,len(rows),expected,'PASS' if ok else 'FAIL',f'{len(cols)} columns')
  if not ok: failures.append(f'{fn}: expected {expected}, got {len(rows)}')
 except Exception as e:
  add('read:'+fn,'error','readable','FAIL',str(e)); failures.append(f'{fn}: {e}')
map_rows=list(csv.DictReader((BASE/'docs'/'Phase_4_16_Schema_Column_Map.csv').open(encoding='utf-8-sig',newline='')))
type_errors=[]
for m in map_rows:
 fn=m['source_csv']; col=m['column_name']; typ=m['postgres_type']
 if fn not in rows_by_file or col not in headers[fn]: continue  # includes optional derived player_key_candidate
 for line,row in enumerate(rows_by_file[fn],2):
  v=row.get(col,'')
  if v=='': continue
  try:
   if typ=='BIGINT':
    if Decimal(v)!=Decimal(v).to_integral_value(): raise ValueError('not integral')
   elif typ.startswith('NUMERIC'): Decimal(v)
   elif typ=='DATE': date.fromisoformat(v)
   elif typ=='BOOLEAN' and v.strip().lower() not in {'true','false','t','f','1','0','yes','no','y','n'}: raise ValueError('invalid boolean')
  except Exception as e:
   type_errors.append(f'{fn}:{line}:{col}={v!r} -> {typ}: {e}')
   if len(type_errors)>=50: break
 if len(type_errors)>=50: break
add('typed_column_casts',f'{len(type_errors)} errors','0 errors','PASS' if not type_errors else 'FAIL',f'{len(map_rows)} schema map rows reviewed')
failures.extend(type_errors)
key_errors=[]
for m in map_rows:
 fn=m['source_csv']; kr=m['key_role'].strip()
 if fn not in rows_by_file or not kr: continue
 keys=[x.strip() for x in kr.split('|')]; seen=set()
 for line,row in enumerate(rows_by_file[fn],2):
  key=tuple(row.get(k,'') for k in keys)
  if any(x=='' for x in key): key_errors.append(f'{fn}:{line}: missing key {keys}')
  elif key in seen: key_errors.append(f'{fn}:{line}: duplicate key {key}')
  seen.add(key)
add('declared_source_key_uniqueness',f'{len(key_errors)} errors','0 errors','PASS' if not key_errors else 'FAIL','Financial and data-quality tables use generated surrogate keys.')
failures.extend(key_errors)
mids={r['match_id'] for r in rows_by_file['Real_Madrid_All_Matches.csv']}; tids={r['match_id'] for r in rows_by_file['Real_Madrid_Match_Team_Stats.csv']}
add('match_team_match_id_set_equality',len(mids&tids),len(mids),'PASS' if mids==tids else 'FAIL',f'{len(mids-tids)} match-only; {len(tids-mids)} team-only')
if mids!=tids: failures.append('match and match-team IDs do not align')
pids={r['player_key_candidate'] for r in rows_by_file['Real_Madrid_Player_ID_Crosswalk.csv']}
for fn in ['Real_Madrid_Player_Season_Stats.csv','Real_Madrid_Player_Competition_Stats.csv','Real_Madrid_Transfers.csv']:
 used={r['player_key_candidate'] for r in rows_by_file[fn] if r.get('player_key_candidate')}; missing=used-pids
 add('player_key_coverage:'+fn,len(missing),0,'PASS' if not missing else 'FAIL',f'{len(used)} distinct referenced keys')
 if missing: failures.append(f'{fn}: {len(missing)} player keys not found in crosswalk')
season_files=['Real_Madrid_All_Matches.csv','Real_Madrid_Player_Season_Stats.csv','Real_Madrid_Player_Competition_Stats.csv','Real_Madrid_Transfers.csv','Real_Madrid_Trophies.csv','Real_Madrid_La_Liga_Standings.csv']
seasons={r['season'] for fn in season_files for r in rows_by_file[fn] if r.get('season')}
add('dim_season_coverage',len(seasons),11,'PASS' if len(seasons)==11 else 'FAIL')
if len(seasons)!=11: failures.append('season dimension should contain 11 seasons')
competitions=set(); editions=set()
for fn in ['Real_Madrid_All_Matches.csv','Real_Madrid_Match_Team_Stats.csv','Real_Madrid_Player_Competition_Stats.csv','Real_Madrid_Trophies.csv']:
 for r in rows_by_file[fn]:
  c=r.get('competition',''); e=r.get('competition_edition','')
  if c: competitions.add(c)
  if c and e:
   if e.endswith('.0'): e=e[:-2]
   editions.add((c,e))
add('dim_competition_coverage',len(competitions),7,'PASS' if len(competitions)==7 else 'FAIL')
add('dim_competition_edition_coverage',len(editions),39,'PASS' if len(editions)==39 else 'FAIL','Trailing .0 removed from numeric-looking edition labels')
if len(competitions)!=7: failures.append('competition dimension should contain 7 competitions')
if len(editions)!=39: failures.append('competition edition dimension should contain 39 observed pairs')
played=sum(r['match_status']=='Played' for r in rows_by_file['Real_Madrid_All_Matches.csv']); cancelled=sum(r['match_status']=='Cancelled' for r in rows_by_file['Real_Madrid_All_Matches.csv'])
add('match_status_counts',f'{played} played / {cancelled} cancelled','630 played / 1 cancelled','PASS' if (played,cancelled)==(630,1) else 'FAIL')
if (played,cancelled)!=(630,1): failures.append('match status counts mismatch')
result_only=sum(r['match_log_available'].strip().lower()=='false' for r in rows_by_file['Real_Madrid_Match_Team_Stats.csv'])
add('result_only_team_match_rows',result_only,15,'PASS' if result_only==15 else 'FAIL')
if result_only!=15: failures.append('result-only rows mismatch')
inter=sum(r['competition']=='FIFA Intercontinental Cup' and r['match_date']=='2024-12-18' and r['opponent']=='Pachuca' and Decimal(r['real_madrid_goals_for'])==3 and Decimal(r['real_madrid_goals_against'])==0 for r in rows_by_file['Real_Madrid_All_Matches.csv'])
add('intercontinental_cup_final',inter,1,'PASS' if inter==1 else 'FAIL','Pachuca 0-3 Real Madrid, 18 December 2024')
if inter!=1: failures.append('Intercontinental Cup final mismatch')
required=['00_create_database.sql','01_create_schemas.sql','02_create_raw_staging.sql','03_load_raw_csvs.psql','04_create_core_tables.sql','05_load_core.sql','06_validate.sql','07_create_views.sql','08_reset_schemas.sql']
missing=[x for x in required if not (BASE/'sql'/x).exists()]
add('deployment_sql_scripts',len(required)-len(missing),len(required),'PASS' if not missing else 'FAIL')
if missing: failures.append(f'missing SQL scripts: {missing}')
add('postgresql_live_deployment','Not executed','Target server required','NOT RUN','No local PostgreSQL server/client or user target connection available.')
result={'status':'FAIL' if failures else 'PASS','check_count':len(checks),'checks':checks,'failures':failures}
print(json.dumps(result,indent=2)); sys.exit(1 if failures else 0)
