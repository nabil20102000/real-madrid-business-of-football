-- Phase 4.16 | Initial read-only analytical views.
CREATE OR REPLACE VIEW core.v_match_results AS
SELECT m.match_id, m.season, s.season_role, m.match_date, m.competition,
       m.competition_edition, m.round, m.opponent, m.real_madrid_venue,
       m.real_madrid_goals_for, m.real_madrid_goals_against, m.match_status,
       m.result_code_source, m.stadium, m.source_url
FROM core.fact_matches m
JOIN core.dim_season s USING (season);

CREATE OR REPLACE VIEW core.v_player_season_summary AS
SELECT p.player_key_candidate, d.display_name, p.season, s.season_role,
       p.appearances, p.starts, p.minutes, p.goals, p.assists,
       p.goal_contributions, p.yellow_cards, p.red_cards,
       p.competition_scope, p.source_name
FROM core.fact_player_season_stats p
JOIN core.dim_player d USING (player_key_candidate)
JOIN core.dim_season s USING (season);

CREATE OR REPLACE VIEW core.v_financial_metrics AS
SELECT reporting_period, metric_name, segment, value_original,
       original_unit, value_eur_million, currency, data_type,
       entity_scope, source_document, source_pdf_page, comparability_note
FROM core.fact_financials;

CREATE OR REPLACE VIEW core.v_trophy_register AS
SELECT t.trophy_id, t.season, s.season_role, t.competition,
       t.competition_edition, t.award_date, t.title_status,
       t.official_reference_url, t.official_validation_status
FROM core.fact_trophies t
JOIN core.dim_season s USING (season);
