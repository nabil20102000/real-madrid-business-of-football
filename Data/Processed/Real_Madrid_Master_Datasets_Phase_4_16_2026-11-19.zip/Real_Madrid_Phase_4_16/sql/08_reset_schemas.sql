-- DESTRUCTIVE: run only when intentionally discarding this database's Phase 4.16 schemas.
DROP SCHEMA IF EXISTS audit CASCADE;
DROP SCHEMA IF EXISTS core CASCADE;
DROP SCHEMA IF EXISTS raw CASCADE;
