-- Phase 4.16 | Curated relational model. Source values are loaded from raw.* tables.

CREATE TABLE IF NOT EXISTS core.dim_season (
    season TEXT PRIMARY KEY,
    season_role TEXT NOT NULL,
    is_baseline BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE TABLE IF NOT EXISTS core.dim_competition (
    competition_name TEXT PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS core.dim_competition_edition (
    competition_name TEXT NOT NULL REFERENCES core.dim_competition(competition_name),
    competition_edition TEXT NOT NULL,
    PRIMARY KEY (competition_name, competition_edition)
);
CREATE TABLE IF NOT EXISTS core.dim_player (
    player_key_candidate TEXT PRIMARY KEY,
    player_id TEXT NOT NULL UNIQUE,
    display_name TEXT,
    source_name_variants TEXT,
    source_presence TEXT,
    id_method TEXT,
    validation_status TEXT,
    is_provisional BOOLEAN NOT NULL DEFAULT TRUE
);


CREATE TABLE IF NOT EXISTS core.fact_matches (
    "match_id" TEXT NOT NULL,
    "season" TEXT,
    "season_role" TEXT,
    "match_date" DATE,
    "competition" TEXT,
    "competition_edition" TEXT,
    "round" TEXT,
    "matchday" BIGINT,
    "home_team" TEXT,
    "away_team" TEXT,
    "opponent" TEXT,
    "real_madrid_venue" TEXT,
    "real_madrid_goals_for" BIGINT,
    "real_madrid_goals_against" BIGINT,
    "home_goals" BIGINT,
    "away_goals" BIGINT,
    "home_goals_90" BIGINT,
    "away_goals_90" BIGINT,
    "home_goals_after_extra_time" BIGINT,
    "away_goals_after_extra_time" BIGINT,
    "home_penalties" BIGINT,
    "away_penalties" BIGINT,
    "result_code_source" TEXT,
    "penalty_goals_for" BIGINT,
    "penalty_goals_against" BIGINT,
    "extra_time_played" BOOLEAN,
    "penalty_shootout" BOOLEAN,
    "decision_note" TEXT,
    "match_status" TEXT,
    "stadium" TEXT,
    "attendance" BIGINT,
    "possession_pct" NUMERIC(8,3),
    "captain" TEXT,
    "formation" TEXT,
    "opponent_formation" TEXT,
    "referee" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_row" BIGINT,
    "source_notes" TEXT,
    "source_url" TEXT,
    "regulation_score_available" BOOLEAN,
    "penalty_winner" TEXT,
    "match_time" TEXT,
    "day" TEXT,
    "match_report_label" TEXT,
    "match_log_available" BOOLEAN,
    "opponent_raw_phase_4_12" TEXT,
    "source_reference_url" TEXT,
    "source_reference_scope" TEXT,
    "source_url_scope" TEXT,
    "opponent_normalization_note" TEXT,
    PRIMARY KEY ("match_id"),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season),
    FOREIGN KEY ("competition") REFERENCES core.dim_competition(competition_name),
    FOREIGN KEY ("competition", "competition_edition") REFERENCES core.dim_competition_edition(competition_name, competition_edition)
);

CREATE TABLE IF NOT EXISTS core.fact_match_team_stats (
    "match_id" TEXT NOT NULL,
    "season" TEXT,
    "season_role" TEXT,
    "match_date" DATE,
    "competition" TEXT,
    "competition_edition" TEXT,
    "round" TEXT,
    "matchday" BIGINT,
    "opponent" TEXT,
    "real_madrid_venue" TEXT,
    "goals_for" BIGINT,
    "goals_against" BIGINT,
    "match_status" TEXT,
    "possession_pct" NUMERIC(8,3),
    "attendance" BIGINT,
    "captain" TEXT,
    "formation" TEXT,
    "opponent_formation" TEXT,
    "referee" TEXT,
    "stadium" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "match_time" TEXT,
    "day" TEXT,
    "match_report_label" TEXT,
    "match_log_notes" TEXT,
    "match_log_available" BOOLEAN,
    "statistics_level" TEXT,
    "coverage_note" TEXT,
    PRIMARY KEY ("match_id"),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season),
    FOREIGN KEY ("competition") REFERENCES core.dim_competition(competition_name),
    FOREIGN KEY ("competition", "competition_edition") REFERENCES core.dim_competition_edition(competition_name, competition_edition)
);

CREATE TABLE IF NOT EXISTS core.fact_player_season_stats (
    "player_id" TEXT,
    "player_key_candidate" TEXT NOT NULL,
    "player_name" TEXT,
    "nation" TEXT,
    "position" TEXT,
    "age" BIGINT,
    "season" TEXT NOT NULL,
    "season_role" TEXT,
    "competition_scope" TEXT,
    "appearances" BIGINT,
    "starts" BIGINT,
    "minutes" BIGINT,
    "nineties" NUMERIC(20,6),
    "goals" BIGINT,
    "assists" BIGINT,
    "goal_contributions" BIGINT,
    "non_penalty_goals" BIGINT,
    "penalties_scored" BIGINT,
    "penalties_attempted" BIGINT,
    "yellow_cards" BIGINT,
    "red_cards" BIGINT,
    "goals_per90" NUMERIC(20,6),
    "assists_per90" NUMERIC(20,6),
    "goal_contributions_per90" NUMERIC(20,6),
    "non_penalty_goals_per90" NUMERIC(20,6),
    "goal_contributions_minus_penalties_per90" NUMERIC(20,6),
    "source_name" TEXT,
    "source_file" TEXT,
    "source_row" BIGINT,
    PRIMARY KEY ("player_key_candidate", "season"),
    FOREIGN KEY ("player_key_candidate") REFERENCES core.dim_player(player_key_candidate),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season)
);

CREATE TABLE IF NOT EXISTS core.fact_player_competition_stats (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name" TEXT,
    "nation" TEXT,
    "position" TEXT,
    "age" BIGINT,
    "season" TEXT,
    "season_role" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_files" TEXT,
    "competition_scope" TEXT,
    "competition_edition_basis" TEXT,
    "appearances" BIGINT,
    "starts" BIGINT,
    "minutes" BIGINT,
    "nineties" NUMERIC(20,6),
    "goals" BIGINT,
    "assists" BIGINT,
    "goal_contributions" BIGINT,
    "non_penalty_goals" BIGINT,
    "penalties_scored" BIGINT,
    "penalties_attempted" BIGINT,
    "yellow_cards" BIGINT,
    "red_cards" BIGINT,
    "goals_per90" NUMERIC(20,6),
    "assists_per90" NUMERIC(20,6),
    "goal_contributions_per90" NUMERIC(20,6),
    "non_penalty_goals_per90" NUMERIC(20,6),
    "goal_contributions_minus_penalties_per90" NUMERIC(20,6),
    "own_goals_by_real_madrid_player" BIGINT,
    "goalkeeper_goals_against" BIGINT,
    "goalkeeper_saves" BIGINT,
    "goalkeeper_save_pct" NUMERIC(8,3),
    "goalkeeper_wins" BIGINT,
    "goalkeeper_draws" BIGINT,
    "goalkeeper_losses" BIGINT,
    "goalkeeper_clean_sheets" BIGINT,
    "goalkeeper_penalties_faced" BIGINT,
    "goalkeeper_penalties_saved" BIGINT,
    "goalkeeper_penalties_missed" BIGINT,
    "source_schema" TEXT,
    "data_status" TEXT,
    "player_competition_key" TEXT NOT NULL,
    PRIMARY KEY ("player_competition_key"),
    FOREIGN KEY ("player_key_candidate") REFERENCES core.dim_player(player_key_candidate),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season),
    FOREIGN KEY ("competition") REFERENCES core.dim_competition(competition_name),
    FOREIGN KEY ("competition", "competition_edition") REFERENCES core.dim_competition_edition(competition_name, competition_edition)
);

CREATE TABLE IF NOT EXISTS core.fact_player_match_stats (
    "match_id" TEXT,
    "match_date" DATE,
    "season" TEXT,
    "competition" TEXT,
    "player_id" TEXT,
    "player_name" TEXT,
    "team" TEXT,
    "opponent" TEXT,
    "started" BOOLEAN,
    "minutes" NUMERIC(20,6),
    "position" TEXT,
    "goals" BIGINT,
    "assists" BIGINT,
    "shots" BIGINT,
    "shots_on_target" BIGINT,
    "xg" NUMERIC(20,6),
    "xa" NUMERIC(20,6),
    "key_passes" BIGINT,
    "tackles" BIGINT,
    "interceptions" BIGINT,
    "blocks" BIGINT,
    "successful_dribbles" BIGINT,
    "saves" BIGINT,
    "clean_sheet" BOOLEAN,
    "yellow_cards" BIGINT,
    "red_cards" BIGINT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "source_page" BIGINT,
    "notes" TEXT,
    player_match_stats_id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    player_key_candidate TEXT REFERENCES core.dim_player(player_key_candidate),
    FOREIGN KEY ("match_id") REFERENCES core.fact_matches(match_id)
);

CREATE TABLE IF NOT EXISTS core.fact_transfers (
    "transfer_id" TEXT NOT NULL,
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name" TEXT,
    "season" TEXT,
    "transfer_date" DATE,
    "direction" TEXT,
    "from_club" TEXT,
    "to_club" TEXT,
    "transfer_type" TEXT,
    "transfer_fee" BIGINT,
    "fee_currency" TEXT,
    "fee_status" TEXT,
    "loan_fee" BIGINT,
    "purchase_option" TEXT,
    "market_value_eur" TEXT,
    "market_value_date" DATE,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "source_access_date" DATE,
    "notes" TEXT,
    "reported_fee_text" TEXT,
    "counterparty_club_as_listed" TEXT,
    "original_season_label" TEXT,
    PRIMARY KEY ("transfer_id"),
    FOREIGN KEY ("player_key_candidate") REFERENCES core.dim_player(player_key_candidate),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season)
);

CREATE TABLE IF NOT EXISTS core.fact_financials (
    "reporting_period" TEXT,
    "metric_name" TEXT,
    "segment" TEXT,
    "value_original" NUMERIC(20,6),
    "original_unit" TEXT,
    "value_eur_million" NUMERIC(20,6),
    "currency" TEXT,
    "data_type" TEXT,
    "entity_scope" TEXT,
    "source_document" TEXT,
    "source_pdf_page" BIGINT,
    "source_note" TEXT,
    "source_page_reference" TEXT,
    "comparability_note" TEXT,
    financial_row_id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS core.fact_trophies (
    "trophy_id" TEXT NOT NULL,
    "season" TEXT,
    "season_role" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "award_date" DATE,
    "title_status" TEXT,
    "evidence_type" TEXT,
    "evidence_reference" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "notes" TEXT,
    "official_reference_url" TEXT,
    "official_validation_status" TEXT,
    "official_validation_note" TEXT,
    PRIMARY KEY ("trophy_id"),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season),
    FOREIGN KEY ("competition") REFERENCES core.dim_competition(competition_name),
    FOREIGN KEY ("competition", "competition_edition") REFERENCES core.dim_competition_edition(competition_name, competition_edition)
);

CREATE TABLE IF NOT EXISTS core.fact_laliga_standings (
    "season" TEXT NOT NULL,
    "season_role" TEXT,
    "team" TEXT,
    "final_position" BIGINT,
    "played" BIGINT,
    "wins" BIGINT,
    "draws" BIGINT,
    "losses" BIGINT,
    "goals_for" BIGINT,
    "goals_against" BIGINT,
    "goal_difference" BIGINT,
    "points" BIGINT,
    "league_champion" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "notes" TEXT,
    "official_champion_reference_url" TEXT,
    "official_champion_validation_status" TEXT,
    "full_fixture_recalculation_status" TEXT,
    "validation_note" TEXT,
    PRIMARY KEY ("season"),
    FOREIGN KEY ("season") REFERENCES core.dim_season(season)
);

CREATE TABLE IF NOT EXISTS core.player_name_alias_crosswalk (
    "player_id" TEXT,
    "player_key_candidate" TEXT NOT NULL,
    "canonical_display_name" TEXT,
    "source_name_alias" TEXT NOT NULL,
    "normalized_alias_key" TEXT,
    "source_presence" TEXT,
    "alias_handling_note" TEXT,
    PRIMARY KEY ("player_key_candidate", "source_name_alias"),
    FOREIGN KEY ("player_key_candidate") REFERENCES core.dim_player(player_key_candidate)
);

CREATE TABLE IF NOT EXISTS audit.player_identity_audit (
    "player_id" TEXT,
    "player_key_candidate" TEXT NOT NULL,
    "canonical_display_name" TEXT,
    "source_name_aliases" TEXT,
    "alias_count" BIGINT,
    "source_presence" TEXT,
    "single_token_name_flag" TEXT,
    "external_id_status" TEXT,
    "identity_status" TEXT,
    PRIMARY KEY ("player_key_candidate"),
    FOREIGN KEY ("player_key_candidate") REFERENCES core.dim_player(player_key_candidate)
);

CREATE TABLE IF NOT EXISTS audit.trophy_official_validation (
    "trophy_id" TEXT NOT NULL,
    "season" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "official_winner" TEXT,
    "official_reference_url" TEXT,
    "reference_scope" TEXT,
    "validation_status" TEXT,
    "validation_note" TEXT,
    PRIMARY KEY ("trophy_id"),
    FOREIGN KEY ("trophy_id") REFERENCES core.fact_trophies(trophy_id)
);

CREATE TABLE IF NOT EXISTS audit.laliga_standings_official_validation (
    "season" TEXT NOT NULL,
    "season_role" TEXT,
    "real_madrid_position" BIGINT,
    "points" BIGINT,
    "wins" BIGINT,
    "draws" BIGINT,
    "losses" BIGINT,
    "goals_for" BIGINT,
    "goals_against" BIGINT,
    "goal_difference" BIGINT,
    "source_fixture_rows" BIGINT,
    "source_team_count" BIGINT,
    "missing_final_scores" BIGINT,
    "dataset_champion" TEXT,
    "official_champion" TEXT,
    "official_champion_reference_url" TEXT,
    "full_fixture_recalculation_status" TEXT,
    "official_champion_check_status" TEXT,
    "real_madrid_points_tie_status" TEXT,
    "validation_note" TEXT,
    PRIMARY KEY ("season"),
    FOREIGN KEY ("season") REFERENCES core.fact_laliga_standings(season)
);

CREATE TABLE IF NOT EXISTS audit.source_register (
    "source_id" TEXT NOT NULL,
    "source_name" TEXT,
    "dataset_coverage" TEXT,
    "period_coverage" TEXT,
    "provided_archive_or_file" TEXT,
    "source_files" TEXT,
    "provenance_note" TEXT,
    "remaining_source_action" TEXT,
    "source_url" TEXT,
    "source_url_scope" TEXT,
    "retrieval_checked_on" DATE,
    "license_or_reuse_note" TEXT,
    "phase_4_13_update" TEXT,
    "phase_4_15_update" TEXT,
    PRIMARY KEY ("source_id")
);

CREATE TABLE IF NOT EXISTS audit.data_quality_log (
    "finding_id" TEXT,
    "dataset_or_area" TEXT,
    "severity" TEXT,
    "finding" TEXT,
    "recommended_action" TEXT,
    "status" TEXT,
    data_quality_row_id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS audit.dataset_inventory (
    "dataset_file" TEXT NOT NULL,
    "records" BIGINT,
    "coverage" TEXT,
    "status" TEXT,
    "limitations" TEXT,
    PRIMARY KEY ("dataset_file")
);

CREATE TABLE IF NOT EXISTS audit.data_dictionary (
    "table_name" TEXT NOT NULL,
    "field_name" TEXT NOT NULL,
    "data_type" TEXT,
    "non_null_count" BIGINT,
    "null_count" BIGINT,
    "distinct_non_null_values" TEXT,
    "sample_values" TEXT,
    "definition_or_handling" TEXT,
    PRIMARY KEY ("table_name", "field_name")
);

CREATE TABLE IF NOT EXISTS audit.data_model_grain_map (
    "proposed_table" TEXT NOT NULL,
    "source_csv" TEXT,
    "grain" TEXT,
    "candidate_key" TEXT,
    "integration_notes" TEXT,
    PRIMARY KEY ("proposed_table")
);

CREATE TABLE IF NOT EXISTS audit.phase_4_14_validation_checks (
    "check" TEXT NOT NULL,
    "observed" TEXT,
    "expected" TEXT,
    "status" TEXT,
    "notes" TEXT,
    PRIMARY KEY ("check")
);

CREATE TABLE IF NOT EXISTS audit.phase_4_15_validation_checks (
    "check" TEXT NOT NULL,
    "observed" TEXT,
    "expected" TEXT,
    "status" TEXT,
    "notes" TEXT,
    PRIMARY KEY ("check")
);

CREATE INDEX IF NOT EXISTS ix_fact_matches_season ON core.fact_matches(season);
CREATE INDEX IF NOT EXISTS ix_fact_matches_competition_date ON core.fact_matches(competition, match_date);
CREATE INDEX IF NOT EXISTS ix_fact_player_season_season ON core.fact_player_season_stats(season);
CREATE INDEX IF NOT EXISTS ix_fact_player_competition_season ON core.fact_player_competition_stats(season, competition);
CREATE INDEX IF NOT EXISTS ix_fact_transfers_player_season ON core.fact_transfers(player_key_candidate, season);
CREATE INDEX IF NOT EXISTS ix_fact_financials_period_metric ON core.fact_financials(reporting_period, metric_name);
CREATE INDEX IF NOT EXISTS ix_fact_trophies_season ON core.fact_trophies(season);

