-- Phase 4.16 | Raw staging tables; all source columns remain TEXT until curated load.

CREATE TABLE IF NOT EXISTS raw.data_dictionary (
    "table_name" TEXT,
    "field_name" TEXT,
    "data_type" TEXT,
    "non_null_count" TEXT,
    "null_count" TEXT,
    "distinct_non_null_values" TEXT,
    "sample_values" TEXT,
    "definition_or_handling" TEXT
);

CREATE TABLE IF NOT EXISTS raw.data_model_grain_map (
    "proposed_table" TEXT,
    "source_csv" TEXT,
    "grain" TEXT,
    "candidate_key" TEXT,
    "integration_notes" TEXT
);

CREATE TABLE IF NOT EXISTS raw.data_quality_log (
    "finding_id" TEXT,
    "dataset_or_area" TEXT,
    "severity" TEXT,
    "finding" TEXT,
    "recommended_action" TEXT,
    "status" TEXT
);

CREATE TABLE IF NOT EXISTS raw.dataset_inventory (
    "dataset_file" TEXT,
    "records" TEXT,
    "coverage" TEXT,
    "status" TEXT,
    "limitations" TEXT
);

CREATE TABLE IF NOT EXISTS raw.la_liga_standings_official_validation (
    "season" TEXT,
    "season_role" TEXT,
    "real_madrid_position" TEXT,
    "points" TEXT,
    "wins" TEXT,
    "draws" TEXT,
    "losses" TEXT,
    "goals_for" TEXT,
    "goals_against" TEXT,
    "goal_difference" TEXT,
    "source_fixture_rows" TEXT,
    "source_team_count" TEXT,
    "missing_final_scores" TEXT,
    "dataset_champion" TEXT,
    "official_champion" TEXT,
    "official_champion_reference_url" TEXT,
    "full_fixture_recalculation_status" TEXT,
    "official_champion_check_status" TEXT,
    "real_madrid_points_tie_status" TEXT,
    "validation_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.phase_4_14_validation_checks (
    "check" TEXT,
    "observed" TEXT,
    "expected" TEXT,
    "status" TEXT,
    "notes" TEXT
);

CREATE TABLE IF NOT EXISTS raw.phase_4_15_validation_checks (
    "check" TEXT,
    "observed" TEXT,
    "expected" TEXT,
    "status" TEXT,
    "notes" TEXT
);

CREATE TABLE IF NOT EXISTS raw.player_identity_audit (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "canonical_display_name" TEXT,
    "source_name_aliases" TEXT,
    "alias_count" TEXT,
    "source_presence" TEXT,
    "single_token_name_flag" TEXT,
    "external_id_status" TEXT,
    "identity_status" TEXT
);

CREATE TABLE IF NOT EXISTS raw.player_name_alias_crosswalk (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "canonical_display_name" TEXT,
    "source_name_alias" TEXT,
    "normalized_alias_key" TEXT,
    "source_presence" TEXT,
    "alias_handling_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_all_matches (
    "match_id" TEXT,
    "season" TEXT,
    "season_role" TEXT,
    "match_date" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "round" TEXT,
    "matchday" TEXT,
    "home_team" TEXT,
    "away_team" TEXT,
    "opponent" TEXT,
    "real_madrid_venue" TEXT,
    "real_madrid_goals_for" TEXT,
    "real_madrid_goals_against" TEXT,
    "home_goals" TEXT,
    "away_goals" TEXT,
    "home_goals_90" TEXT,
    "away_goals_90" TEXT,
    "home_goals_after_extra_time" TEXT,
    "away_goals_after_extra_time" TEXT,
    "home_penalties" TEXT,
    "away_penalties" TEXT,
    "result_code_source" TEXT,
    "penalty_goals_for" TEXT,
    "penalty_goals_against" TEXT,
    "extra_time_played" TEXT,
    "penalty_shootout" TEXT,
    "decision_note" TEXT,
    "match_status" TEXT,
    "stadium" TEXT,
    "attendance" TEXT,
    "possession_pct" TEXT,
    "captain" TEXT,
    "formation" TEXT,
    "opponent_formation" TEXT,
    "referee" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_row" TEXT,
    "source_notes" TEXT,
    "source_url" TEXT,
    "regulation_score_available" TEXT,
    "penalty_winner" TEXT,
    "match_time" TEXT,
    "day" TEXT,
    "match_report_label" TEXT,
    "match_log_available" TEXT,
    "opponent_raw_phase_4_12" TEXT,
    "source_reference_url" TEXT,
    "source_reference_scope" TEXT,
    "source_url_scope" TEXT,
    "opponent_normalization_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_financials (
    "reporting_period" TEXT,
    "metric_name" TEXT,
    "segment" TEXT,
    "value_original" TEXT,
    "original_unit" TEXT,
    "value_eur_million" TEXT,
    "currency" TEXT,
    "data_type" TEXT,
    "entity_scope" TEXT,
    "source_document" TEXT,
    "source_pdf_page" TEXT,
    "source_note" TEXT,
    "source_page_reference" TEXT,
    "comparability_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_la_liga_standings (
    "season" TEXT,
    "season_role" TEXT,
    "team" TEXT,
    "final_position" TEXT,
    "played" TEXT,
    "wins" TEXT,
    "draws" TEXT,
    "losses" TEXT,
    "goals_for" TEXT,
    "goals_against" TEXT,
    "goal_difference" TEXT,
    "points" TEXT,
    "league_champion" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "notes" TEXT,
    "official_champion_reference_url" TEXT,
    "official_champion_validation_status" TEXT,
    "full_fixture_recalculation_status" TEXT,
    "validation_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_match_team_stats (
    "match_id" TEXT,
    "season" TEXT,
    "season_role" TEXT,
    "match_date" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "round" TEXT,
    "matchday" TEXT,
    "opponent" TEXT,
    "real_madrid_venue" TEXT,
    "goals_for" TEXT,
    "goals_against" TEXT,
    "match_status" TEXT,
    "possession_pct" TEXT,
    "attendance" TEXT,
    "captain" TEXT,
    "formation" TEXT,
    "opponent_formation" TEXT,
    "referee" TEXT,
    "stadium" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "match_time" TEXT,
    "day" TEXT,
    "match_report_label" TEXT,
    "match_log_notes" TEXT,
    "match_log_available" TEXT,
    "statistics_level" TEXT,
    "coverage_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_player_competition_stats (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name" TEXT,
    "nation" TEXT,
    "position" TEXT,
    "age" TEXT,
    "season" TEXT,
    "season_role" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_files" TEXT,
    "competition_scope" TEXT,
    "competition_edition_basis" TEXT,
    "appearances" TEXT,
    "starts" TEXT,
    "minutes" TEXT,
    "nineties" TEXT,
    "goals" TEXT,
    "assists" TEXT,
    "goal_contributions" TEXT,
    "non_penalty_goals" TEXT,
    "penalties_scored" TEXT,
    "penalties_attempted" TEXT,
    "yellow_cards" TEXT,
    "red_cards" TEXT,
    "goals_per90" TEXT,
    "assists_per90" TEXT,
    "goal_contributions_per90" TEXT,
    "non_penalty_goals_per90" TEXT,
    "goal_contributions_minus_penalties_per90" TEXT,
    "own_goals_by_real_madrid_player" TEXT,
    "goalkeeper_goals_against" TEXT,
    "goalkeeper_saves" TEXT,
    "goalkeeper_save_pct" TEXT,
    "goalkeeper_wins" TEXT,
    "goalkeeper_draws" TEXT,
    "goalkeeper_losses" TEXT,
    "goalkeeper_clean_sheets" TEXT,
    "goalkeeper_penalties_faced" TEXT,
    "goalkeeper_penalties_saved" TEXT,
    "goalkeeper_penalties_missed" TEXT,
    "source_schema" TEXT,
    "data_status" TEXT,
    "player_competition_key" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_player_id_crosswalk (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name_variants" TEXT,
    "source_presence" TEXT,
    "id_method" TEXT,
    "validation_status" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_player_match_stats (
    "match_id" TEXT,
    "match_date" TEXT,
    "season" TEXT,
    "competition" TEXT,
    "player_id" TEXT,
    "player_name" TEXT,
    "team" TEXT,
    "opponent" TEXT,
    "started" TEXT,
    "minutes" TEXT,
    "position" TEXT,
    "goals" TEXT,
    "assists" TEXT,
    "shots" TEXT,
    "shots_on_target" TEXT,
    "xg" TEXT,
    "xa" TEXT,
    "key_passes" TEXT,
    "tackles" TEXT,
    "interceptions" TEXT,
    "blocks" TEXT,
    "successful_dribbles" TEXT,
    "saves" TEXT,
    "clean_sheet" TEXT,
    "yellow_cards" TEXT,
    "red_cards" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "source_page" TEXT,
    "notes" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_player_season_stats (
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name" TEXT,
    "nation" TEXT,
    "position" TEXT,
    "age" TEXT,
    "season" TEXT,
    "season_role" TEXT,
    "competition_scope" TEXT,
    "appearances" TEXT,
    "starts" TEXT,
    "minutes" TEXT,
    "nineties" TEXT,
    "goals" TEXT,
    "assists" TEXT,
    "goal_contributions" TEXT,
    "non_penalty_goals" TEXT,
    "penalties_scored" TEXT,
    "penalties_attempted" TEXT,
    "yellow_cards" TEXT,
    "red_cards" TEXT,
    "goals_per90" TEXT,
    "assists_per90" TEXT,
    "goal_contributions_per90" TEXT,
    "non_penalty_goals_per90" TEXT,
    "goal_contributions_minus_penalties_per90" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_row" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_transfers (
    "transfer_id" TEXT,
    "player_id" TEXT,
    "player_key_candidate" TEXT,
    "player_name" TEXT,
    "season" TEXT,
    "transfer_date" TEXT,
    "direction" TEXT,
    "from_club" TEXT,
    "to_club" TEXT,
    "transfer_type" TEXT,
    "transfer_fee" TEXT,
    "fee_currency" TEXT,
    "fee_status" TEXT,
    "loan_fee" TEXT,
    "purchase_option" TEXT,
    "market_value_eur" TEXT,
    "market_value_date" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "source_url" TEXT,
    "source_access_date" TEXT,
    "notes" TEXT,
    "reported_fee_text" TEXT,
    "counterparty_club_as_listed" TEXT,
    "original_season_label" TEXT
);

CREATE TABLE IF NOT EXISTS raw.real_madrid_trophies (
    "trophy_id" TEXT,
    "season" TEXT,
    "season_role" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "award_date" TEXT,
    "title_status" TEXT,
    "evidence_type" TEXT,
    "evidence_reference" TEXT,
    "source_name" TEXT,
    "source_file" TEXT,
    "notes" TEXT,
    "official_reference_url" TEXT,
    "official_validation_status" TEXT,
    "official_validation_note" TEXT
);

CREATE TABLE IF NOT EXISTS raw.source_register (
    "source_id" TEXT,
    "source_name" TEXT,
    "dataset_coverage" TEXT,
    "period_coverage" TEXT,
    "provided_archive_or_file" TEXT,
    "source_files" TEXT,
    "provenance_note" TEXT,
    "remaining_source_action" TEXT,
    "source_url" TEXT,
    "source_url_scope" TEXT,
    "retrieval_checked_on" TEXT,
    "license_or_reuse_note" TEXT,
    "phase_4_13_update" TEXT,
    "phase_4_15_update" TEXT
);

CREATE TABLE IF NOT EXISTS raw.trophy_official_validation (
    "trophy_id" TEXT,
    "season" TEXT,
    "competition" TEXT,
    "competition_edition" TEXT,
    "official_winner" TEXT,
    "official_reference_url" TEXT,
    "reference_scope" TEXT,
    "validation_status" TEXT,
    "validation_note" TEXT
);
