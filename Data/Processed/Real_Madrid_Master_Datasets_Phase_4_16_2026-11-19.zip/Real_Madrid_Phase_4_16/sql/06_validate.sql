-- Phase 4.16 | Post-load assertions. Any mismatch raises an exception.
DO $$
DECLARE
    failures TEXT[] := ARRAY[]::TEXT[];
BEGIN
    IF (SELECT count(*) FROM core.fact_matches) <> 631 THEN failures := array_append(failures, 'fact_matches expected 631'); END IF;
    IF (SELECT count(*) FROM core.fact_match_team_stats) <> 631 THEN failures := array_append(failures, 'fact_match_team_stats expected 631'); END IF;
    IF (SELECT count(*) FROM core.fact_player_season_stats) <> 386 THEN failures := array_append(failures, 'fact_player_season_stats expected 386'); END IF;
    IF (SELECT count(*) FROM core.fact_player_competition_stats) <> 343 THEN failures := array_append(failures, 'fact_player_competition_stats expected 343'); END IF;
    IF (SELECT count(*) FROM core.fact_player_match_stats) <> 0 THEN failures := array_append(failures, 'fact_player_match_stats expected 0 (schema only)'); END IF;
    IF (SELECT count(*) FROM core.fact_transfers) <> 214 THEN failures := array_append(failures, 'fact_transfers expected 214'); END IF;
    IF (SELECT count(*) FROM core.fact_financials) <> 204 THEN failures := array_append(failures, 'fact_financials expected 204'); END IF;
    IF (SELECT count(*) FROM core.fact_trophies) <> 23 THEN failures := array_append(failures, 'fact_trophies expected 23'); END IF;
    IF (SELECT count(*) FROM core.fact_laliga_standings) <> 11 THEN failures := array_append(failures, 'fact_laliga_standings expected 11'); END IF;
    IF (SELECT count(*) FROM core.dim_player) <> 157 THEN failures := array_append(failures, 'dim_player expected 157'); END IF;
    IF (SELECT count(*) FROM core.player_name_alias_crosswalk) <> 159 THEN failures := array_append(failures, 'player_name_alias_crosswalk expected 159'); END IF;
    IF (SELECT count(*) FROM audit.player_identity_audit) <> 157 THEN failures := array_append(failures, 'player_identity_audit expected 157'); END IF;
    IF (SELECT count(*) FROM audit.trophy_official_validation) <> 23 THEN failures := array_append(failures, 'trophy_official_validation expected 23'); END IF;
    IF (SELECT count(*) FROM audit.laliga_standings_official_validation) <> 11 THEN failures := array_append(failures, 'laliga_standings_official_validation expected 11'); END IF;
    IF (SELECT count(*) FROM audit.source_register) <> 41 THEN failures := array_append(failures, 'source_register expected 41'); END IF;
    IF (SELECT count(*) FROM audit.data_quality_log) <> 47 THEN failures := array_append(failures, 'data_quality_log expected 47'); END IF;
    IF (SELECT count(*) FROM audit.data_dictionary) <> 313 THEN failures := array_append(failures, 'data_dictionary expected 313'); END IF;
    IF (SELECT count(*) FROM audit.dataset_inventory) <> 32 THEN failures := array_append(failures, 'dataset_inventory expected 32'); END IF;
    IF (SELECT count(*) FROM audit.data_model_grain_map) <> 11 THEN failures := array_append(failures, 'data_model_grain_map expected 11'); END IF;
    IF (SELECT count(*) FROM audit.phase_4_14_validation_checks) <> 27 THEN failures := array_append(failures, 'Phase 4.14 validation checks expected 27'); END IF;
    IF (SELECT count(*) FROM audit.phase_4_15_validation_checks) <> 27 THEN failures := array_append(failures, 'Phase 4.15 validation checks expected 27'); END IF;
    IF (SELECT count(*) FROM core.fact_matches WHERE match_status = 'Played') <> 630 THEN failures := array_append(failures, 'played match count expected 630'); END IF;
    IF (SELECT count(*) FROM core.fact_matches WHERE match_status = 'Cancelled') <> 1 THEN failures := array_append(failures, 'cancelled match count expected 1'); END IF;
    IF (SELECT count(*) FROM core.fact_match_team_stats WHERE match_log_available IS FALSE) <> 15 THEN failures := array_append(failures, 'result-only match team rows expected 15'); END IF;
    IF (SELECT count(*) FROM core.fact_matches WHERE competition = 'FIFA Intercontinental Cup' AND match_date = DATE '2024-12-18' AND opponent = 'Pachuca' AND real_madrid_goals_for = 3 AND real_madrid_goals_against = 0) <> 1 THEN failures := array_append(failures, '2024 Intercontinental Cup final not found'); END IF;
    IF (SELECT count(*) FROM core.fact_match_team_stats m LEFT JOIN core.fact_matches f USING (match_id) WHERE f.match_id IS NULL) <> 0 THEN failures := array_append(failures, 'orphan match team rows'); END IF;
    IF (SELECT count(*) FROM core.fact_player_season_stats p LEFT JOIN core.dim_player d USING (player_key_candidate) WHERE d.player_key_candidate IS NULL) <> 0 THEN failures := array_append(failures, 'orphan player-season rows'); END IF;
    IF (SELECT count(*) FROM core.fact_player_competition_stats p LEFT JOIN core.dim_player d USING (player_key_candidate) WHERE d.player_key_candidate IS NULL) <> 0 THEN failures := array_append(failures, 'orphan player-competition rows'); END IF;
    IF (SELECT count(*) FROM core.fact_transfers t LEFT JOIN core.dim_player d USING (player_key_candidate) WHERE t.player_key_candidate IS NOT NULL AND d.player_key_candidate IS NULL) <> 0 THEN failures := array_append(failures, 'orphan transfer player rows'); END IF;
    IF cardinality(failures) > 0 THEN RAISE EXCEPTION 'Phase 4.16 validation failed: %', array_to_string(failures, '; '); END IF;
END $$;

-- Summary counts for the deployment log.
SELECT 'fact_matches' AS table_name, count(*) AS rows FROM core.fact_matches
UNION ALL SELECT 'fact_match_team_stats', count(*) FROM core.fact_match_team_stats
UNION ALL SELECT 'fact_player_season_stats', count(*) FROM core.fact_player_season_stats
UNION ALL SELECT 'fact_player_competition_stats', count(*) FROM core.fact_player_competition_stats
UNION ALL SELECT 'fact_player_match_stats', count(*) FROM core.fact_player_match_stats
UNION ALL SELECT 'fact_transfers', count(*) FROM core.fact_transfers
UNION ALL SELECT 'fact_financials', count(*) FROM core.fact_financials
UNION ALL SELECT 'fact_trophies', count(*) FROM core.fact_trophies
UNION ALL SELECT 'fact_laliga_standings', count(*) FROM core.fact_laliga_standings
UNION ALL SELECT 'dim_player', count(*) FROM core.dim_player
UNION ALL SELECT 'source_register', count(*) FROM audit.source_register
ORDER BY table_name;
