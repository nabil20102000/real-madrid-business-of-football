-- Phase 4.16 | PostgreSQL database creation (run separately as a database administrator)
-- PostgreSQL 13+ recommended. This statement fails if the database already exists.
CREATE DATABASE real_madrid_analytics WITH ENCODING 'UTF8' TEMPLATE template0;
