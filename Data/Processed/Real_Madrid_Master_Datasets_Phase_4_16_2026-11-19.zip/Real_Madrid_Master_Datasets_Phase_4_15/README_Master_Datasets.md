# Real Madrid — Master Datasets (Phase 4.15)

**Release date:** 19 November 2026  
**Project:** Real Madrid: The Business of Football — A Decade of Sporting Performance, Financial Growth and Strategic Investment

This is the current Phase 4.15 master-data handoff. It builds on Phase 4.14, adds official reference validation, corrects trophy edition metadata, and adds the previously omitted 2024 FIFA Intercontinental Cup final.

## Current scope
- Historical baseline: 2015-16 (`season_role=Baseline`)
- Main period: 2016-17 through 2025-26
- Men's senior first team; Real Madrid-centric records.

## Core dataset status

| Dataset | Rows | Status |
|---|---:|---|
| `Real_Madrid_All_Matches.csv` | 631 | 630 played events + 1 cancelled event; includes 2024 Intercontinental Cup final |
| `Real_Madrid_Match_Team_Stats.csv` | 631 | 616 detailed team logs + 15 result-only rows |
| `Real_Madrid_Player_Season_Stats.csv` | 386 | All-competition season aggregates |
| `Real_Madrid_Player_Competition_Stats.csv` | 343 | Copa del Rey and FIFA Club World Cup 2022/2025 only |
| `Real_Madrid_Player_Match_Stats.csv` | 0 | Schema only; no individual player-match records supplied |
| `Real_Madrid_Transfers.csv` | 214 | Transaction records; fees and dates remain incomplete |
| `Real_Madrid_Player_ID_Crosswalk.csv` | 157 | Provisional name-based identities; one orphan header removed |
| `Real_Madrid_Financials.csv` | 204 | Financial metrics with reporting scope preserved |
| `Real_Madrid_Trophies.csv` | 23 | All 23 title/edition rows have official references |
| `Real_Madrid_La_Liga_Standings.csv` | 11 | 11 official champion checks; numeric RM lines recomputed from fixtures |

## Phase 4.15 official validation changes
- Added 2024 FIFA Intercontinental Cup final: Pachuca 0-3 Real Madrid, 18 December 2024.
- Added a result-only match row and a distinct trophy row for the Intercontinental Cup.
- Corrected Spanish Super Cup competition editions to official calendar years 2020, 2022 and 2024.
- Verified all 23 trophy title/edition records against official club/competition references.
- Verified official La Liga champion identities for all 11 seasons.
- Recomputed Real Madrid's detailed La Liga line from 4,180 supplied fixture rows.
- Removed one orphan `Player` header artifact from the player crosswalk.
- Added a 159-row alias crosswalk for 157 provisional player identities; 20 single-token names remain flagged.

## Critical limitations
1. Player-match statistics remain unpopulated.
2. Player IDs remain provisional; no authoritative external IDs were available in the supplied files.
3. La Liga official champion references do not provide the complete detailed Real Madrid table row for every season; numeric values are recomputed from the supplied fixtures.
4. Source versions, exact original download URLs and licensing/reuse terms remain unavailable for several user-supplied files.
5. Player competition aggregates cover Copa del Rey and FIFA Club World Cup 2022/2025 only.
6. Transfer fee/date gaps, financial reporting scope changes and derived trophy/standings provenance remain documented.

## Version lineage
- Phase 4.12 source snapshots retained under `Source_Snapshots/Phase_4_12/`.
- Phase 4.14 pre-update snapshots retained under `Source_Snapshots/Phase_4_14/`.
- Phase 4.13 remediation evidence retained under `Audit_Archive/Phase_4_13/`.
- Original raw archives and financial PDFs were not modified.

## PostgreSQL preparation
See `PostgreSQL_Load_Readiness.md` and `Data_Model_Grain_Map.csv`. The package supports staging-schema design and controlled import testing; PostgreSQL has not yet been created or loaded.
