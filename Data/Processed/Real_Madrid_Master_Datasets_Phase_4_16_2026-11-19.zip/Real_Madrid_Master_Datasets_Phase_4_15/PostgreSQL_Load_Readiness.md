# PostgreSQL Load Readiness — Phase 4.15

## Status
Phase 4.15 master package is consolidated and reference-validated. PostgreSQL has **not** yet been created or loaded.

## Recommended loading order
1. Import CSVs to staging tables with raw source values preserved.
2. Validate data types, row counts, nulls and candidate keys.
3. Create dimensions (season, competition, player, financial category).
4. Load fact tables after foreign-key and row-count checks.
5. Add production constraints only after player identities and source references are reviewed.
6. Create analytical views only after reconciliation.

## Match facts
- `Real_Madrid_All_Matches.csv`: 631 event rows, including 630 played and 1 cancelled.
- `Real_Madrid_Match_Team_Stats.csv`: 631 rows; 616 detailed team logs and 15 result-only rows.
- `match_log_available=false` means the row has a result but no corresponding detailed Sports Reference team log.
- The 2024 FIFA Intercontinental Cup final is included as a distinct competition, result-only event.

## Trophy and competition controls
- `FIFA Club World Cup Morocco 2022` remains edition 2022 even though its final took place on 11 February 2023.
- `FIFA Intercontinental Cup 2024` is a separate competition and must not be merged into the FIFA Club World Cup category.
- Spanish Super Cup edition years follow RFEF's calendar-year labels: 2017, 2020, 2022, 2024.
- Trophy records include official reference URLs and validation status.

## Player identity controls
- Use the 157 `player_key_candidate` values only as provisional staging keys.
- The `Player_Name_Alias_Crosswalk.csv` stores normalized spelling variants.
- The `Player_Identity_Audit.csv` flags 20 single-token/nickname-only names for manual review.
- Do not treat `RMPLR-...` values as official FBref, Transfermarkt or Real Madrid IDs.
- Do not impose production identity constraints until external IDs or authoritative identity evidence are obtained.

## La Liga controls
- 11 seasons × 380 fixture rows = 4,180 supplied match records.
- The Real Madrid line was recomputed from these source fixtures.
- Official champion references validate the champion identity, not every detailed historical table cell.
- Keep 2015-16 as the baseline season.

## Financial and transfer controls
- Preserve original financial units, normalized EUR million values, entity scope and data type.
- Missing transfer/loan fees are not zero.
- Preserve loan fees separately from permanent transfer fees.
- Do not infer exact transfer dates where absent.

## Release gates before production
- Obtain authoritative external player IDs and resolve alias/mononym review.
- Obtain complete official archived La Liga standings tables if the analysis requires independent official validation of every table cell.
- Confirm original download versions, URLs and licensing/reuse rights for supplied datasets.
- Confirm all intended match and competition scopes before final production load.
