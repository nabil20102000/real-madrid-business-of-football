# Phase 4.11 — Eleven-Season Player Statistics Validation

## Scope and method

- Canonical master: `Real_Madrid_Master_Datasets_2026-11-18_UPDATED.zip` → `Real_Madrid_Master_Datasets_2026-11-18_UPDATED/Real_Madrid_Player_Season_Stats.csv`.
- FBref inputs: ten season Standard Stats HTML exports in `all sportsref excel.zip`, plus the corrected 2022–23 replacement CSV.
- The old 2022–23 workbook in the original archive was deliberately excluded because it had already been identified as a partial extract.
- Player keys use repaired text encoding, Unicode normalization, and accent-insensitive name matching.
- Metrics compared: appearances, starts, minutes, 90s, goals, assists, goal contributions, non-penalty goals, penalties scored/attempted, yellow/red cards, and five per-90 measures.
- Integer/count fields and minutes are compared exactly; 90s and per-90 rates allow for display rounding.
- Master data is read-only throughout this audit.

## Overall results

- Master rows: **386**; FBref rows: **386**.
- Matched player-season identities: **386**.
- Master-only identities: **0**; FBref-only identities: **0**.
- Duplicate master keys: **0**; duplicate FBref keys: **0**.
- Metric values compared: **6562**; matches: **5617**; mismatches: **0**.
- Master missing: **0**; FBref missing: **0**; both missing: **945**.
- Demographic field mismatches (nation/position/age): **0**.

## Season-by-season results

| season   |   master_player_rows |   fbref_player_rows |   master_unique_players |   fbref_unique_players |   matched_players |   master_only_players |   fbref_only_players |   metric_values_compared |   metric_matches |   metric_mismatches |   master_missing_values |   fbref_missing_values |   both_missing_values |
|:---------|---------------------:|--------------------:|------------------------:|-----------------------:|------------------:|----------------------:|---------------------:|-------------------------:|-----------------:|--------------------:|------------------------:|-----------------------:|----------------------:|
| 2015-16  |                   29 |                  29 |                      29 |                     29 |                29 |                     0 |                    0 |                      493 |              448 |                   0 |                       0 |                      0 |                    45 |
| 2016-17  |                   28 |                  28 |                      28 |                     28 |                28 |                     0 |                    0 |                      476 |              461 |                   0 |                       0 |                      0 |                    15 |
| 2017-18  |                   32 |                  32 |                      32 |                     32 |                32 |                     0 |                    0 |                      544 |              499 |                   0 |                       0 |                      0 |                    45 |
| 2018-19  |                   36 |                  36 |                      36 |                     36 |                36 |                     0 |                    0 |                      612 |              522 |                   0 |                       0 |                      0 |                    90 |
| 2019-20  |                   32 |                  32 |                      32 |                     32 |                32 |                     0 |                    0 |                      544 |              454 |                   0 |                       0 |                      0 |                    90 |
| 2020-21  |                   37 |                  37 |                      37 |                     37 |                37 |                     0 |                    0 |                      629 |              539 |                   0 |                       0 |                      0 |                    90 |
| 2021-22  |                   36 |                  36 |                      36 |                     36 |                36 |                     0 |                    0 |                      612 |              537 |                   0 |                       0 |                      0 |                    75 |
| 2022-23  |                   36 |                  36 |                      36 |                     36 |                36 |                     0 |                    0 |                      612 |              477 |                   0 |                       0 |                      0 |                   135 |
| 2023-24  |                   38 |                  38 |                      38 |                     38 |                38 |                     0 |                    0 |                      646 |              511 |                   0 |                       0 |                      0 |                   135 |
| 2024-25  |                   38 |                  38 |                      38 |                     38 |                38 |                     0 |                    0 |                      646 |              541 |                   0 |                       0 |                      0 |                   105 |
| 2025-26  |                   44 |                  44 |                      44 |                     44 |                44 |                     0 |                    0 |                      748 |              628 |                   0 |                       0 |                      0 |                   120 |

## Metric-level results

| metric                                   |   BOTH_MISSING |   MATCH |   MISMATCH |   MASTER_MISSING |   FBREF_MISSING |   total_records |
|:-----------------------------------------|---------------:|--------:|-----------:|-----------------:|----------------:|----------------:|
| appearances                              |              0 |     386 |          0 |                0 |               0 |             386 |
| assists                                  |             63 |     323 |          0 |                0 |               0 |             386 |
| assists_per90                            |             63 |     323 |          0 |                0 |               0 |             386 |
| goal_contributions                       |             63 |     323 |          0 |                0 |               0 |             386 |
| goal_contributions_minus_penalties_per90 |             63 |     323 |          0 |                0 |               0 |             386 |
| goal_contributions_per90                 |             63 |     323 |          0 |                0 |               0 |             386 |
| goals                                    |             63 |     323 |          0 |                0 |               0 |             386 |
| goals_per90                              |             63 |     323 |          0 |                0 |               0 |             386 |
| minutes                                  |             63 |     323 |          0 |                0 |               0 |             386 |
| nineties                                 |             63 |     323 |          0 |                0 |               0 |             386 |
| non_penalty_goals                        |             63 |     323 |          0 |                0 |               0 |             386 |
| non_penalty_goals_per90                  |             63 |     323 |          0 |                0 |               0 |             386 |
| penalties_attempted                      |             63 |     323 |          0 |                0 |               0 |             386 |
| penalties_scored                         |             63 |     323 |          0 |                0 |               0 |             386 |
| red_cards                                |             63 |     323 |          0 |                0 |               0 |             386 |
| starts                                   |              0 |     386 |          0 |                0 |               0 |             386 |
| yellow_cards                             |             63 |     323 |          0 |                0 |               0 |             386 |

## Source inventory

| season   | source_file                                          | extraction_method                                                                |   source_rows_before_aggregate_filter |   player_rows_after_aggregate_filter |   unique_player_keys |   duplicate_player_keys |   blank_player_keys |   missing_MP |   missing_Min |
|:---------|:-----------------------------------------------------|:---------------------------------------------------------------------------------|--------------------------------------:|-------------------------------------:|---------------------:|------------------------:|--------------------:|-------------:|--------------:|
| 2015-16  | sportsref_download stats 15-16.xls                   | HTML table parsed from FBref .xls export                                         |                                    29 |                                   29 |                   29 |                       0 |                   0 |            0 |             3 |
| 2016-17  | sportsref_download stats 16-17.xls                   | HTML table parsed from FBref .xls export                                         |                                    28 |                                   28 |                   28 |                       0 |                   0 |            0 |             1 |
| 2017-18  | sportsref_download stats 17-18.xls                   | HTML table parsed from FBref .xls export                                         |                                    32 |                                   32 |                   32 |                       0 |                   0 |            0 |             3 |
| 2018-19  | sportsref_download stats 18-19.xls                   | HTML table parsed from FBref .xls export                                         |                                    36 |                                   36 |                   36 |                       0 |                   0 |            0 |             6 |
| 2019-20  | sportsref_download stats 19-20.xls                   | HTML table parsed from FBref .xls export                                         |                                    32 |                                   32 |                   32 |                       0 |                   0 |            0 |             6 |
| 2020-21  | sportsref_download stats 20-21.xls                   | HTML table parsed from FBref .xls export                                         |                                    37 |                                   37 |                   37 |                       0 |                   0 |            0 |             6 |
| 2021-22  | sportsref_download stats 21-22.xls                   | HTML table parsed from FBref .xls export                                         |                                    36 |                                   36 |                   36 |                       0 |                   0 |            0 |             5 |
| 2022-23  | Real_Madrid_FBref_2022-23_Standard_Stats_Staging.csv | Corrected replacement CSV; archive workbook excluded as known incomplete extract |                                    36 |                                   36 |                   36 |                       0 |                   0 |            0 |             9 |
| 2023-24  | sportsref_download stats 23-24.xls                   | HTML table parsed from FBref .xls export                                         |                                    38 |                                   38 |                   38 |                       0 |                   0 |            0 |             9 |
| 2024-25  | sportsref_download stats 24-25.xls                   | HTML table parsed from FBref .xls export                                         |                                    38 |                                   38 |                   38 |                       0 |                   0 |            0 |             7 |
| 2025-26  | sportsref_download stats 25-26.xls                   | HTML table parsed from FBref .xls export                                         |                                    44 |                                   44 |                   44 |                       0 |                   0 |            0 |             8 |


## Additional artifact reconciliation — standalone CSV vs updated ZIP

The separate generated `Real_Madrid_Player_Season_Stats.csv` artifact was compared with the player-season CSV inside the updated master ZIP. All 386 season/player keys match, and the non-identity statistical fields match. However, the standalone artifact has blank `player_id` values in all 386 rows and uses a different `player_key_candidate` format. The updated ZIP member has populated `player_id` values and is therefore the canonical version for this audit. Do not replace the updated ZIP member with the standalone artifact.

## Zero-appearance records

There are 63 player-season records with `MP=0` and `Starts=0`, with minutes and the other 15 statistical fields blank in both sources. These account for all 945 `BOTH_MISSING` metric cells (63 × 15). Preserve the source NULLs. If an analysis requires zero-valued event counts, derive them in a separate analytical view with explicit rules; keep per-90 values NULL because they are undefined without minutes.

## Interpretation and limitations

- A zero-mismatch result means the supplied master values reconcile with the supplied FBref Standard Stats exports under the stated tolerances; it does not independently prove that FBref is historically correct.
- The 2022–23 source used here is the corrected replacement CSV, not the old workbook in the ZIP.
- Any missing values must be interpreted by context. Per-90 rates for zero-minute players are undefined and should remain null; do not globally replace nulls with zero.
- Name normalization is a reconciliation aid. Namesakes and player identity edge cases should continue to be governed by the player ID crosswalk and source provenance.
- No master CSV or ZIP was overwritten or modified.
