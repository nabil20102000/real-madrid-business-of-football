# Master Dataset Changelog — Phase 4.13

**Date:** 19 November 2026

## Derivative outputs created
1. UCL opponent display labels: removed leading country-code prefixes for 133 rows; retained original labels in `opponent_raw_phase_4_12`; preserved all match IDs.
2. Spanish Super Cup 2017: populated Camp Nou (13 August) and Santiago Bernabéu (16 August) in the clean match copy, with official Real Madrid retrospective reference.
3. Competition player statistics: created a common schema for 343 Copa del Rey and FIFA Club World Cup player aggregate rows.
4. Copa del Rey repeated headers: excluded two non-player rows from the harmonized output; preserved them in a separate audit file.
5. Copa del Rey edition: assigned edition year 2025 to 29 2025-26 rows, based on the established tournament start-year convention.
6. Copa del Rey goals: reconciled six team goals to opponent own goals; no individual player goal totals were altered.
7. Source register: added verified source-family landing URLs and explicit license/reuse caveats.

## Immutable source controls
- Original `Real_Madrid_Master_Datasets_2026-11-18_UPDATED.zip` was not modified.
- Original `Real_Madrid_All_Matches.csv` and `Real_Madrid_Player_Competition_Stats.csv` were not modified.
- Uploaded ZIP archives and source files were not modified.
