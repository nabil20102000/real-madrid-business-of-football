# Phase 4.13 — Competition Data Remediation & Master Dataset Refinement

**Status:** Completed as a controlled derivative-data remediation. Original source archives and Phase 4.12 master CSVs were not overwritten.

## Executive summary

- UEFA Champions League opponent labels normalized: **133/133**; country-code prefixes removed, raw labels retained in the crosswalk.
- Copa del Rey player-goal reconciliation: **110 player-attributed goals + 6 opponent own goals = 116 team match goals**.
- Repeated header artifacts: **2** excluded from the harmonized analytical output and retained in an audit file.
- Missing Copa del Rey edition values: **29** rows assigned edition **2025** in the derivative output, following the existing start-year convention.
- Harmonized competition-player data: **343 rows** (290 Copa del Rey; 53 FIFA Club World Cup).
- Spanish Super Cup 2017 venues: both gaps filled from a Real Madrid official retrospective.
- Source provenance: competition/repository URLs added as clearly labelled dataset-level references; no generic landing page is misrepresented as a match-specific URL.

## 1. UEFA Champions League opponent labels

The original UCL `opponent` field contained a leading country code in every one of the 133 rows. The clean derivative removes only that prefix. The original value is retained in `opponent_raw_phase_4_12`, and the match IDs remain unchanged.

The accompanying crosswalk contains the original label, normalized label, OpenFootball source-name candidate and match ID. The QA check uses the exact set of original country-code tokens, so legitimate club-name prefixes such as `RB` are not misclassified.

## 2. Copa del Rey goal reconciliation

The previous six-goal difference is explained by opponent own goals, not missing player scoring rows:

| Season | Team match goals | Player-attributed goals | Opponent own goals | Reconciled |
|---|---:|---:|---:|---:|
| 2015-16 | 3 | 3 | 0 | 3 |
| 2016-17 | 22 | 20 | 2 | 22 |
| 2017-18 | 11 | 11 | 0 | 11 |
| 2018-19 | 21 | 21 | 0 | 21 |
| 2019-20 | 10 | 9 | 1 | 10 |
| 2020-21 | 1 | 1 | 0 | 1 |
| 2021-22 | 5 | 4 | 1 | 5 |
| 2022-23 | 13 | 13 | 0 | 13 |
| 2023-24 | 5 | 4 | 1 | 5 |
| 2024-25 | 20 | 20 | 0 | 20 |
| 2025-26 | 5 | 4 | 1 | 5 |
| **Total** | **116** | **110** | **6** | **116** |

The six events are documented individually in `Real_Madrid_Copa_del_Rey_Own_Goal_Events.csv`:
- 2016-17: Gianni Zuiverloon and César Morgado (Cultural Leonesa).
- 2019-20: Góngora (Unionistas / U Salamanca).
- 2021-22: José Juan Figueras (Alcoyano).
- 2023-24: Jan Oblak (Atlético Madrid).
- 2025-26: Manu Farrando (CF Talavera).

These are team goals credited to opponents as own goals. They are not added to individual Real Madrid player goal totals.

## 3. Competition player statistics

The harmonized file contains 343 rows:
- Copa del Rey: 290 player-season/tournament rows after excluding two repeated header rows.
- FIFA Club World Cup: 53 player-edition rows from the supplied 2022 and 2025 FBref exports.

The harmonized output includes a shared set of appearance, minutes, goal, assist, penalty, card, goalkeeper and per-90 metrics. Copa del Rey source-specific columns are mapped into the common schema; the original source columns remain preserved in the original master.

Missing values are not filled with zero. There are 56 zero-appearance player rows; their unavailable performance metrics remain null.

**Coverage caveat:** FIFA Club World Cup player aggregates in the supplied source cover the 2022 and 2025 editions only. The 2016, 2017 and 2018 Club World Cup match results remain result-only in the match master; no player competition aggregates were supplied for those editions.

## 4. Competition edition identifiers

The 29 Copa del Rey player-stat rows for season 2025-26 had blank `competition_edition`. The derivative assigns 2025 based on the tournament start year, consistent with the other Copa del Rey season rows (e.g. 2024-25 → 2024). The assignments are separately listed for review.

## 5. Spanish Super Cup 2017 metadata

The two 2017 records now have:
- 13 August 2017: Camp Nou.
- 16 August 2017: Santiago Bernabéu.

Both values are confirmed by Real Madrid's official retrospective. The original RSSSF source field was not silently overwritten in the raw archive; the clean match copy records the additional official source and URL.

## 6. Source provenance

The revised source register includes confirmed dataset/repository landing pages for:
- La Liga: Football-Data.co.uk.
- UEFA Champions League: OpenFootball.
- FIFA Club World Cup: OpenFootball.
- Copa del Rey: FBref.
- Spanish Super Cup: RSSSF.
- UEFA Super Cup: UEFA.

These are explicitly identified as dataset-level or competition-level URLs, not individual match URLs. Exact original download URLs, retrieval dates or licenses remain unrecorded for several user-supplied workbooks/PDFs and have been left blank rather than guessed.

## 7. Validation result

| check                                      |   observed |   expected | status   | notes                                                                                                                   |
|:-------------------------------------------|-----------:|-----------:|:---------|:------------------------------------------------------------------------------------------------------------------------|
| Match master row count                     |        630 |        630 | PASS     | No source match rows added or removed.                                                                                  |
| Unique match IDs                           |        630 |        630 | PASS     | Stable identifiers preserved.                                                                                           |
| Match IDs changed                          |          0 |          0 | PASS     | Opponent display normalization does not alter IDs.                                                                      |
| UCL opponent labels cleaned                |        133 |        133 | PASS     | Remaining original country-code tokens at label start: 0; two-letter club prefix 'RB' is not treated as a country code. |
| Spanish Super Cup 2017 venues populated    |          2 |          2 | PASS     | Camp Nou and Santiago Bernabéu verified from official retrospective.                                                    |
| Harmonized player-competition rows         |        343 |        343 | PASS     | Copa del Rey 290; FIFA Club World Cup 53.                                                                               |
| Header artifacts excluded                  |          2 |          2 | PASS     | Excluded from harmonized output; preserved in separate audit file.                                                      |
| Duplicate player-competition keys          |          0 |          0 | PASS     | Key = player candidate + season + competition + edition.                                                                |
| Missing competition edition values         |          0 |          0 | PASS     | 29 Copa del Rey 2025-26 rows assigned edition 2025.                                                                     |
| Zero-appearance rows retained              |         56 |         56 | PASS     | Zero appearances remain zero; missing performance metrics remain null.                                                  |
| Zero-appearance rows with goals still null |         56 |         56 | PASS     | No zero-fill applied to unavailable performance values.                                                                 |
| Verified opponent own-goal events          |          6 |          6 | PASS     | All six events link to a played match with matching Real Madrid score.                                                  |
| Copa del Rey season goal reconciliations   |         11 |         11 | PASS     | Player goals + opponent own goals = team match goals in all seasons.                                                    |
| Dataset-level source references populated  |        630 |        630 | PASS     | Reference URL scope is explicitly dataset/competition-level, not match-specific.                                        |

## 8. Remaining limitations

- `Real_Madrid_Player_Match_Stats.csv` remains header-only; no player-by-match statistics were supplied.
- Player IDs remain provisional name-based keys.
- FBref/RSSSF/official-site reuse terms should be reviewed before redistribution.
- The clean files are derivative outputs; the original master ZIP and raw archives remain unchanged.

## Release recommendation

**Match data:** opponent labels and 2017 Spanish Super Cup venue metadata are clean in the derivative.

**Competition player data:** harmonized for the supplied coverage, with missing values and historical CWC coverage gaps preserved.

**Copa del Rey goals:** reconciled using six independently documented opponent own goals.

Use the Phase 4.13 clean derivative files for the next analytical build, while retaining the original master files as immutable source snapshots.
