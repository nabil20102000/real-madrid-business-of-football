# Real Madrid — Phase 4.13 Remediation Package

This package contains controlled derivative outputs for the Phase 4.12 findings. It does not overwrite the original master datasets or uploaded source archives.

## Main outputs
- `Real_Madrid_All_Matches_Phase_4_13_Clean.csv`
- `Real_Madrid_Player_Competition_Stats_Harmonized.csv`
- `Real_Madrid_Copa_del_Rey_Own_Goal_Events.csv`
- `Real_Madrid_Copa_del_Rey_Goal_Reconciliation_By_Season.csv`
- `Real_Madrid_UCL_Opponent_Name_Crosswalk.csv`
- `Real_Madrid_Source_Register_Phase_4_13.csv`

## Audit outputs
- `Phase_4_13_Validation_Report.md`
- `Phase_4_13_Validation_Checks.csv`
- `Phase_4_13_Finding_Log.csv`
- `Phase_4_13_Data_Dictionary.csv`
- `Phase_4_13_Excluded_Header_Artifacts.csv`
- `Phase_4_13_Copa_Edition_Assignments.csv`
- `Phase_4_13_Source_References.csv`

## Key controls
- Match IDs are unchanged.
- Raw UCL opponent labels are retained in the clean match file.
- Opponent own goals are not added to player goals.
- Zero-appearance players remain present.
- Missing performance values remain null.
- The two repeated header rows are excluded only from the harmonized output.
- Dataset-level URLs are not represented as match-specific URLs.
