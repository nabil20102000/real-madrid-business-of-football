"""
Phase 4.13 core remediation script.
Inputs expected:
- Real_Madrid_All_Matches.csv
- Real_Madrid_Player_Competition_Stats.csv
Outputs are derivative files; input files are not overwritten.
"""
from pathlib import Path
import re
import numpy as np
import pandas as pd

INPUT = Path("input")
OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)

matches = pd.read_csv(INPUT / "Real_Madrid_All_Matches.csv", encoding="utf-8-sig")
competition_stats = pd.read_csv(INPUT / "Real_Madrid_Player_Competition_Stats.csv", encoding="utf-8-sig")

# Normalize UCL display labels, preserving the raw values.
matches["opponent_raw_phase_4_12"] = matches["opponent"]
ucl = matches["competition"].eq("UEFA Champions League")
matches.loc[ucl, "opponent"] = (
    matches.loc[ucl, "opponent"].astype(str)
    .str.replace(r"^[A-Za-z]{2,3}\s+", "", regex=True).str.strip()
)

# Fill only the two verified 2017 Spanish Super Cup stadiums.
official_url = "https://www.realmadrid.com/en-US/news/football/first-team/latest-news/septimo-aniversario-de-la-10-supercopa-de-espana-16-08-2024"
venues = {"2017-08-13": "Camp Nou", "2017-08-16": "Santiago Bernabéu"}
for date, venue in venues.items():
    mask = matches["competition"].eq("Spanish Super Cup") & matches["match_date"].eq(date)
    matches.loc[mask, "stadium"] = venue
    matches.loc[mask, "source_url"] = official_url

# Exclude repeated header rows from the analytical derivative only.
header = (
    competition_stats["player_name"].astype(str).str.strip().str.lower().eq("player")
    | competition_stats["position"].astype(str).str.strip().str.lower().eq("pos")
)
stats = competition_stats.loc[~header].copy()

# Assign edition 2025 to 2025-26 Copa del Rey rows; keep all other source editions.
stats["competition_edition"] = pd.to_numeric(stats["competition_edition"], errors="coerce")
fill = stats["competition"].eq("Copa del Rey") & stats["season"].eq("2025-26") & stats["competition_edition"].isna()
stats.loc[fill, "competition_edition"] = 2025

def ncol(df, col):
    return pd.to_numeric(df[col], errors="coerce") if col in df else pd.Series(np.nan, index=df.index)

def coalesce(df, cols):
    out = pd.Series(np.nan, index=df.index)
    for c in cols:
        if c in df:
            out = out.combine_first(ncol(df, c))
    return out

# Build a compact shared standard-stat schema.
out = stats[["player_id", "player_key_candidate", "player_name", "nation", "position",
             "age", "season", "competition", "competition_edition", "source_file", "source_files"]].copy()
cdr = stats["competition"].eq("Copa del Rey")
cwc = stats["competition"].eq("FIFA Club World Cup")

mapping_cdr = {
    "appearances": ["stats_standard_569_MP", "stats_playing_time_569_MP"],
    "starts": ["stats_standard_569_Playing_Time_Starts", "stats_playing_time_569_Starts_Starts"],
    "minutes": ["stats_standard_569_Playing_Time_Min", "stats_playing_time_569_Playing_Time_Min"],
    "goals": ["stats_standard_569_Performance_Gls", "stats_shooting_569_Standard_Gls"],
    "assists": ["stats_standard_569_Performance_Ast"],
    "goal_contributions": ["stats_standard_569_Performance_G_A"],
    "non_penalty_goals": ["stats_standard_569_Performance_G_PK"],
    "penalties_scored": ["stats_standard_569_Performance_PK"],
    "penalties_attempted": ["stats_standard_569_Performance_PKatt"],
    "yellow_cards": ["stats_standard_569_Performance_CrdY", "stats_misc_569_Performance_CrdY"],
    "red_cards": ["stats_standard_569_Performance_CrdR", "stats_misc_569_Performance_CrdR"],
}
mapping_cwc = {
    "appearances": ["standard_MP"],
    "starts": ["standard_Playing_Time_Starts"],
    "minutes": ["standard_Playing_Time_Min"],
    "goals": ["standard_Performance_Gls"],
    "assists": ["standard_Performance_Ast"],
    "goal_contributions": ["standard_Performance_G_A"],
    "non_penalty_goals": ["standard_Performance_G_PK"],
    "penalties_scored": ["standard_Performance_PK"],
    "penalties_attempted": ["standard_Performance_PKatt"],
    "yellow_cards": ["standard_Performance_CrdY"],
    "red_cards": ["standard_Performance_CrdR"],
}
for metric in sorted(set(mapping_cdr) | set(mapping_cwc)):
    out[metric] = np.nan
    if metric in mapping_cdr:
        out.loc[cdr, metric] = coalesce(stats.loc[cdr], mapping_cdr[metric])
    if metric in mapping_cwc:
        out.loc[cwc, metric] = coalesce(stats.loc[cwc], mapping_cwc[metric])

out["data_status"] = np.where(
    out["appearances"].eq(0),
    "Zero appearances; performance metrics left null",
    "Player competition aggregate available"
)

matches.to_csv(OUTPUT / "Real_Madrid_All_Matches_Phase_4_13_Clean.csv", index=False, encoding="utf-8-sig")
out.to_csv(OUTPUT / "Real_Madrid_Player_Competition_Stats_Harmonized.csv", index=False, encoding="utf-8-sig")
print("Wrote derivative files to", OUTPUT)
