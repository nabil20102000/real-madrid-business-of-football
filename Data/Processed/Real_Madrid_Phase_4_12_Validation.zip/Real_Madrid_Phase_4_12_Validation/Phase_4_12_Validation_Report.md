# Phase 4.12 — Match & Competition Validation

**Status:** Completed as an audit. The supplied master datasets were not modified.

## Executive result

- Match master: **630 rows**, **630 unique match IDs**.
- Source reconciliation: **630/630 matches found** in the supplied competition source files.
- Score reconciliation: **630/630 PASS** after keeping extra-time and penalty-shoot-out scores in their separate fields.
- Match status: **629 played**, **1 cancelled**.
- Match-team table: **630/630** one-to-one match IDs; **616** team match-log rows and **14** result-only FIFA Club World Cup rows.
- La Liga final-table validation: **11/11 seasons PASS**.
- Trophy evidence references: **22/22 internally consistent** with a decisive match win or a first-place La Liga table.
- UEFA Super Cup official check: **5/5 editions PASS**.
- FIFA Club World Cup result check: **14/14 PASS**.

## Match source reconciliation

| Competition | Master rows | Source rows matched | Score checks passed |
|---|---:|---:|---:|
| Copa del Rey | 45 | 45 | 45 |
| FIFA Club World Cup | 14 | 14 | 14 |
| La Liga | 418 | 418 | 418 |
| Spanish Super Cup | 15 | 15 | 15 |
| UEFA Champions League | 133 | 133 | 133 |
| UEFA Super Cup | 5 | 5 | 5 |
| **Total** | **630** | **630** | **630** |

Source families used:
- La Liga: supplied full-season fixture CSVs (418 Real Madrid fixtures; 380 fixtures and 20 teams per season).
- UEFA Champions League: supplied OpenFootball fixture archive (133 Real Madrid matches).
- Copa del Rey: supplied FBref match-log CSVs (45 rows, including one cancelled Cádiz return fixture).
- Spanish Super Cup: supplied Spanish Super Cup CSV (15 rows).
- UEFA Super Cup: supplied UEFA Super Cup CSV plus UEFA official match reports (5 rows).
- FIFA Club World Cup: supplied OpenFootball fixture files plus FIFA/Real Madrid official results (14 rows).

## Competition and player-stat findings

### FIFA Club World Cup player aggregates

| season   |   competition_edition |   player_rows |   player_appearances |   player_starts |   player_minutes |   player_goals |   match_rows |   match_goals_for | goals_reconcile   |
|:---------|----------------------:|--------------:|---------------------:|----------------:|-----------------:|---------------:|-------------:|------------------:|:------------------|
| 2022-23  |                  2022 |            23 |                   31 |              22 |             1980 |              9 |            2 |                 9 | True              |
| 2024-25  |                  2025 |            30 |                   94 |              66 |             5855 |             11 |            6 |                11 | True              |

The 2022 and 2025 player aggregates reconcile to the corresponding match-result goal totals. No player-match logs are available for the 14 Club World Cup results; these are result-only team records.

### Copa del Rey player-competition data

- 292 source rows across 11 seasons.
- Two repeated header artifacts (`Player` / `Pos`) are present and are not player records.
- 44 actual player rows have zero appearances; preserve their missing performance metrics rather than filling them with zero.
- The normalized `standard_*` columns are blank for the Copa del Rey rows; the source-specific `stats_*_569_*` columns contain the underlying data. A harmonized analytical view is needed.
- 29 rows in season 2025-26 have a blank `competition_edition`; 2025 is a candidate only and has not been written to the master.
- Player-attributed goals total **110**, while Copa del Rey match results total **116**: a **six-goal shortfall** across 2016-17, 2019-20, 2021-22, 2023-24 and 2025-26. The supplied source does not identify the missing scorer/own-goal explanation. Do not automatically classify the difference as own goals.

## Additional integrity observations

- Four UEFA Champions League finals are represented as neutral-venue matches with blank home/away team labels; retain the neutral designation.
- Ten calendar-date/season differences are intentional: seven 2019-20 fixtures delayed into July/August 2020, and three July 2025 Club World Cup matches assigned to the 2024-25 football season.
- All 133 UEFA Champions League opponent display labels contain country-code prefixes or source abbreviations. Candidate clean names are supplied separately. Preserve existing `match_id` values when normalizing display names.
- All 630 `source_url` fields are blank. Local `source_file` references exist, but source URLs/retrieval metadata should be added where verifiable.
- Two 2017 Spanish Super Cup source rows lack venue and source values; these remain blank rather than inferred.
- `Real_Madrid_Player_Match_Stats.csv` is header-only. No player-match statistics should be inferred from match results or competition aggregates.

## UEFA official cross-check

All five UEFA Super Cup scores, attendance values and referees match UEFA official records. The supplied source attendance/referee details for the 2016, 2017, 2018 and 2022 editions were reconciled to UEFA records; the master values are the corrected values.

## Release recommendation

**Match master:** passed source reconciliation.

**Competition/player aggregates:** not yet release-clean. Resolve the findings in `12_Finding_Log.csv`, especially UCL opponent display labels, the Copa del Rey six-goal reconciliation, repeated header rows, missing edition values and schema harmonization.

No original master CSV or source archive was overwritten.
